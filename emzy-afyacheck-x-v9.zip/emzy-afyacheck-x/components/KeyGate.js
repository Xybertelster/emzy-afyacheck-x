'use client';
import { useState, useEffect } from 'react';
const K = 'emzy_keys';
const P = [
  ['groq', 'Groq', 'gsk_', 'Fast everyday chat', 'console.groq.com'],
  ['gemini', 'Google Gemini', 'AIza', 'Photos and documents', 'aistudio.google.com'],
  ['openrouter', 'OpenRouter', 'sk-or-', 'Backup for any model', 'openrouter.ai/keys']
];
const H = { groq: 'x-groq-key', gemini: 'x-gemini-key', openrouter: 'x-openrouter-key' };
const clean = (k) => String(k || '').trim().replace(/^bearer\s+/i, '').replace(/^["']+|["']+$/g, '').trim();
export const loadKeys = () => { try { return JSON.parse(localStorage.getItem(K)) || {}; } catch { return {}; } };
export default function KeyGate() {
  const [open, setOpen] = useState(false); const [v, setV] = useState({}); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false); const [saved, setSaved] = useState({});
  useEffect(() => {
    // migrate the old single Groq key
    try { const old = localStorage.getItem('emzy_groq_key'); if (old && !loadKeys().groq) localStorage.setItem(K, JSON.stringify({ ...loadKeys(), groq: old })); } catch {}
    if (!window.__emzyFetch) {
      window.__emzyFetch = true; const f = window.fetch;
      window.fetch = (u, o = {}) => { try { if (String(u).startsWith('/api/') && !String(u).startsWith('/api/admin')) { const ks = loadKeys(); const h = { ...(o.headers || {}) }; for (const [p, name] of Object.entries(H)) if (ks[p]) h[name] = ks[p]; o = { ...o, headers: h }; } } catch {} return f(u, o); };
    }
    try { navigator.storage && navigator.storage.persist && navigator.storage.persist(); } catch {}
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
    setSaved(loadKeys());
    // Ask only if there is no key on this device AND no key on the server.
    if (!Object.values(loadKeys()).some(Boolean)) fetch('/api/status').then((r) => r.json()).then((d) => { if (!d.ai) setOpen(true); }).catch(() => setOpen(true));
    const h = () => { setMsg(''); setSaved(loadKeys()); setOpen(true); }; window.addEventListener('emzy-need-key', h); return () => window.removeEventListener('emzy-need-key', h);
  }, []);
  async function save() {
    const cur = loadKeys(), next = { ...cur }; const bad = [];
    for (const [id, name, pre] of P) { const k = clean(v[id]); if (!k) continue; if (!k.startsWith(pre)) bad.push(`${name} keys start with ${pre}`); else next[id] = k; }
    if (bad.length) { setMsg(bad.join('. ') + '.'); return; }
    if (!Object.values(next).some(Boolean)) { setMsg('Paste at least one key.'); return; }
    try { localStorage.setItem(K, JSON.stringify(next)); } catch { setMsg('This browser blocked storage. Turn off private mode and try again.'); return; }
    setSaved(next); setV({}); setBusy(true); setMsg('Checking your keys…');
    try { const d = await (await fetch('/api/status?test=1')).json(); if (d.live) { setOpen(false); setMsg(''); } else setMsg('Saved, but no provider answered: ' + (d.reason || 'check the keys') + '. You can still keep them or fix them below.'); } catch { setMsg('Saved. Could not check them right now.'); }
    setBusy(false);
  }
  function remove(id) { const n = { ...loadKeys() }; delete n[id]; localStorage.setItem(K, JSON.stringify(n)); setSaved(n); }
  if (!open) return null;
  return (<div role="dialog" aria-modal="true" aria-label="Connect AI" style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.6)', zIndex: 50, display: 'grid', placeItems: 'center', padding: 12, overflow: 'auto' }}>
    <div className="panel" style={{ maxWidth: 460, width: '100%', maxHeight: '94dvh', overflow: 'auto' }}><h2>Connect EMZY AI</h2>
      <p>Paste one or more keys. You do this once: they are saved on this device and EMZY never asks again. With several keys, EMZY switches automatically if one fails.</p>
      {P.map(([id, name, pre, use, site]) => (<div key={id}><label htmlFor={'k-' + id}>{name} <span className="tag">· {use}</span> {saved[id] && <span className="badge">saved ✓ <button type="button" aria-label={'Remove ' + name} onClick={() => remove(id)} style={{ all: 'unset', cursor: 'pointer' }}>✕</button></span>}</label>
        <input id={'k-' + id} type="password" autoComplete="off" placeholder={saved[id] ? 'Saved. Paste a new key to replace it' : pre + '…'} value={v[id] || ''} onChange={(e) => setV({ ...v, [id]: e.target.value })} /><span className="tag">Get one free at {site}</span></div>))}
      {msg && <p className="err" role="alert">{msg}</p>}
      <div className="row" style={{ marginTop: 10 }}><button type="button" onClick={save} disabled={busy}>{busy ? 'Checking…' : 'Save and start'}</button><button type="button" className="alt" onClick={() => setOpen(false)}>{Object.values(saved).some(Boolean) ? 'Done' : 'Later'}</button></div>
      <p className="tag">Keys stay in this browser and are sent only to EMZY's server to reach the AI provider. Never share them.</p></div></div>);
}
