'use client';
import { useState, useEffect } from 'react';
const N = { groq: 'Groq', gemini: 'Gemini', openrouter: 'OpenRouter' };
export default function AiStatus() {
  const [s, setS] = useState(null);
  useEffect(() => { fetch('/api/status?test=1').then((r) => r.json()).then(setS).catch(() => setS({ ai: false })); }, []);
  if (!s) return null;
  if (!s.ai) return <span className="badge" style={{ background: '#F6D2CD' }}>No AI key yet. Open the menu → AI keys.</span>;
  return <span>{Object.entries(s.providers || {}).map(([p, x]) => <span key={p} className="badge" style={{ background: x.live ? '#BFE8CF' : x.configured ? '#F9E3A8' : '#E4E4E4', marginRight: 4 }}>{N[p]} {x.live ? `✓ ${x.ms}ms` : x.configured ? '⚠' : '–'}</span>)}</span>;
}
