'use client';
import { useState, useEffect } from 'react';
export default function ThemeToggle() {
  const [t, setT] = useState('light');
  useEffect(() => setT(document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light'), []);
  function flip() { const n = t === 'dark' ? 'light' : 'dark'; document.documentElement.dataset.theme = n; try { localStorage.setItem('afya_theme', n); } catch {} setT(n); }
  return <button onClick={flip} className="alt small" aria-label={`Switch to ${t === 'dark' ? 'light' : 'dark'} mode`}>{t === 'dark' ? 'Light mode' : 'Dark mode'}</button>;
}
