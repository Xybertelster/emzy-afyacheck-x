'use client';
import { useState, useEffect } from 'react';
import { get, set } from '../../lib/store';
export default function Evaluation() {
  const [e, setE] = useState([]); useEffect(() => setE(get('emzy_eval', [])), []);
  const up = e.filter((x) => x.ok).length, web = e.filter((x) => x.web).length, fb = e.filter((x) => x.fb).length;
  const pct = (n) => (e.length ? Math.round((n / e.length) * 100) + '%' : '–');
  return (<div className="wrap pad"><h1>Answer quality</h1><p className="lede">Built from the 👍 / 👎 buttons you press in EMZY Chat. Saved on this device.</p>
    <div className="grid"><div className="panel"><h3>{e.length}</h3><p>Rated answers</p></div><div className="panel"><h3>{pct(up)}</h3><p>Helpful</p></div><div className="panel"><h3>{pct(web)}</h3><p>Web-sourced</p></div><div className="panel"><h3>{pct(fb)}</h3><p>Offline fallback</p></div></div>
    <h2 className="mt">Needs improvement</h2>{e.filter((x) => !x.ok).slice(-10).reverse().map((x, i) => <div className="panel" key={i}><b>{x.q}</b><p>{x.a.slice(0, 200)}</p></div>)}
    <p><button type="button" className="alt" onClick={() => { if (confirm('Clear ratings?')) { set('emzy_eval', []); setE([]); } }}>Clear</button></p></div>);
}
