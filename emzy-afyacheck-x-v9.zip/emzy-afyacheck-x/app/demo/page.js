const STEPS = [['Problem', 'Health information is scattered, hard to read and mixed with misinformation.'], ['Ask EMZY', 'On the home page ask about malaria symptoms. Switch the language to Kiswahili.'], ['Safety boundary', 'Type “chest pain and can’t breathe” to show the urgent warning and no diagnosis.'], ['Verify', 'Open Trusted search and compare WHO and Kenya MoH results.'], ['Learn', 'Open the Learning Center and expand malaria prevention.'], ['Relief and owner controls', 'Submit a relief request, then open /owner and change the model and temperature.']];
export const metadata = { title: 'Demo | EMZY AfyaCheck X' };
export default function Demo() {
  return (<div className="wrap" style={{ padding: '2rem 1rem' }}><h1>Demo tour</h1><ol>{STEPS.map(([t, d]) => <li key={t}><b>{t}.</b> {d}</li>)}</ol></div>);
}
