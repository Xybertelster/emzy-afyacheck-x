'use client';
import { useState, useEffect } from 'react';
import { putFile, listFiles, getFile, delFile, clearFiles } from '../../lib/db';
import { download, fmtSize } from '../../lib/store';
const MAX = 1024 * 1024 * 1024, CATS = ['Medical record', 'Bill or receipt', 'Photo or scan', 'Other'];
export default function Vault() {
  const [files, setFiles] = useState([]); const [cat, setCat] = useState(CATS[0]); const [q, setQ] = useState(''); const [msg, setMsg] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false); const [est, setEst] = useState(null);
  const load = async () => { try { const l = await listFiles(); setFiles((l || []).map(({ blob, ...m }) => m).sort((a, b) => b.added - a.added)); const e = await navigator.storage?.estimate?.(); if (e) setEst(e); } catch { setErr('Your browser blocked file storage. Try a normal (not private) window.'); } };
  useEffect(() => { load(); }, []);
  async function add(e) {
    const list = Array.from(e.target.files || []); e.target.value = ''; setErr(''); setMsg('');
    if (!list.length) return; setBusy(true); let n = 0;
    for (const f of list) {
      if (f.size > MAX) { setErr(`${f.name} is over 1 GB and was skipped.`); continue; }
      try { setMsg(`Saving ${f.name} (${fmtSize(f.size)})…`); await putFile({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), name: f.name, size: f.size, type: f.type, cat, added: Date.now(), blob: f }); n++; }
      catch { setErr(`Could not save ${f.name}. Your device may be out of storage space.`); }
    }
    setBusy(false); setMsg(n ? `Saved ${n} file(s) on this device.` : ''); load();
  }
  async function dl(id) { const r = await getFile(id); if (r) download(r.name, r.blob); }
  async function rm(id) { if (!confirm('Delete this file from this device?')) return; await delFile(id); load(); }
  async function wipe() { if (!confirm('Delete ALL vault files from this device?')) return; await clearFiles(); load(); }
  const shown = files.filter((f) => f.name.toLowerCase().includes(q.toLowerCase())); const total = files.reduce((a, f) => a + f.size, 0);
  return (
    <div className="wrap pad"><h1>File vault</h1>
      <p className="notice" style={{ textAlign: 'left', borderRadius: 8 }}>Files stay on this device only and are never sent to a server, so large files (100 MB and more) work. Clearing browser data deletes them, so keep your own copy of anything important.</p>
      <div className="panel mt"><label htmlFor="c">Category for new files</label><select id="c" value={cat} onChange={(e) => setCat(e.target.value)}>{CATS.map((c) => <option key={c}>{c}</option>)}</select>
        <label htmlFor="f">Choose files (up to 1 GB each)</label><input id="f" type="file" multiple onChange={add} disabled={busy} />
        {msg && <p className="ok" role="status">{msg}</p>}{err && <p className="err" role="alert">{err}</p>}
        <p className="tag">{files.length} file(s), {fmtSize(total)} used{est?.quota ? ` · browser allows about ${fmtSize(est.quota)}` : ''}</p></div>
      <div className="row mt"><input aria-label="Search files" placeholder="Search files" value={q} onChange={(e) => setQ(e.target.value)} />{files.length > 0 && <button className="alt" onClick={wipe}>Delete all</button>}</div>
      {shown.length === 0 && <p className="empty mt">No files yet. Choose files above to store them here.</p>}
      <div className="grid mt" style={{ gridTemplateColumns: '1fr' }}>{shown.map((f) => <div className="panel row" key={f.id} style={{ alignItems: 'center' }}><div style={{ flex: '1 1 200px' }}><b style={{ wordBreak: 'break-all' }}>{f.name}</b><p className="tag" style={{ margin: 0 }}>{f.cat} · {fmtSize(f.size)} · {new Date(f.added).toLocaleDateString()}</p></div><button onClick={() => dl(f.id)}>Download</button><button className="alt" onClick={() => rm(f.id)}>Delete</button></div>)}</div>
    </div>
  );
}
