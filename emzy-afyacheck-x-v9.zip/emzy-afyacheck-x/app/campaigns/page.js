import { SEASON } from '../../lib/topics';
const C = [
  ['Handwashing', 'Soap, water, 20 seconds: before food, after the toilet.'],
  ['Malaria prevention', 'Treated nets, clearing standing water, testing fevers early.'],
  ['Safe water', 'Boil or treat water and store it covered.'],
  ['Mental wellbeing', 'Talk early, sleep well, ask for help.'],
  ['Healthy eating for children', 'Varied foods, small frequent meals, growth checks.'],
  ['First aid', 'Bleeding, burns and when to call 999 or 112.']
];
export const metadata = { title: 'Campaigns | EMZY AfyaCheck X' };
export default function Campaigns() {
  return (<div className="wrap pad"><div className="hero2"><h1>Health campaigns</h1><p>Now: {SEASON.name}. {SEASON.note}</p></div>
    <div className="grid">{C.map(([t, d]) => <div className="panel" key={t}><h3>{t}</h3><p>{d}</p><a className="btn" href="/progress">Learn the steps</a> <a className="btn alt" href={'/chat?q=' + encodeURIComponent('Explain ' + t + ' in simple terms.')}>Ask EMZY</a></div>)}</div>
    <p className="tag">Official campaign dates and programmes: check the Kenya Ministry of Health and your county health office.</p></div>);
}
