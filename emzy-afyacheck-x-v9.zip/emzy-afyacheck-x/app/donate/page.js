'use client';
import { useState, useEffect } from 'react';
import { get, set, SEED, KES, raisedFor, tier } from '../../lib/store';
const TIERS = [['Supporter', 500], ['Champion', 5000], ['Patron', 50000], ['Millionaire Circle', 1000000]];
export default function Donate() {
  const [amt, setAmt] = useState(5000); const [who, setWho] = useState(''); const [anon, setAnon] = useState(false); const [msg, setMsg] = useState(''); const [pl, setPl] = useState([]); const [mine, setMine] = useState([]);
  useEffect(() => { setPl(get('afya_pledges', [])); setMine(get('afya_cases', [])); }, []);
  const open = [...mine, ...SEED]; const need = open.reduce((a, c) => a + Math.max(0, c.goal - raisedFor(c, pl)), 0);
  function give(e) {
    e.preventDefault(); const a = Math.round(+amt);
    if (!(a >= 50)) return setMsg('Enter at least KES 50.');
    if (!anon && who.trim().length < 2) return setMsg('Enter your name or choose anonymous.');
    const p = { id: Date.now().toString(36), caseId: 'fund', amount: a, name: anon ? 'Anonymous' : who.trim().slice(0, 60), at: new Date().toISOString() };
    const n = [p, ...pl]; setPl(n); set('afya_pledges', n); setMsg(`Thank you. ${KES(a)} pledged to the general relief fund (${tier(a)}). No money was collected.`);
  }
  return (
    <div className="wrap pad">
      <h1>Donate</h1>
      <p className="lede">Pledge to the general fund, or choose a case in the <a href="/relief">marketplace</a>. Everything here is a simulated pledge for the prototype.</p>
      <div className="grid mt">{TIERS.map(([n, v]) => <div className="panel" key={n}><span className="badge">{n}</span><p className="stat">{KES(v)}</p><button onClick={() => setAmt(v)}>Use this amount</button></div>)}</div>
      <form onSubmit={give} className="panel mt" style={{ maxWidth: 520 }}>
        <label htmlFor="a">Amount (KES)</label><input id="a" type="number" min="50" value={amt} onChange={(e) => setAmt(e.target.value)} />
        <label htmlFor="w">Your name</label><input id="w" value={who} onChange={(e) => setWho(e.target.value)} disabled={anon} />
        <label className="opt"><input type="checkbox" checked={anon} onChange={(e) => setAnon(e.target.checked)} /> Give anonymously</label>
        <p className="tag">Your pledge would cover about {need ? Math.min(100, ((+amt || 0) / need) * 100).toFixed(1) : 0}% of the {KES(need)} still needed across open cases.</p>
        {msg && <p className={msg.startsWith('Thank') ? 'ok' : 'err'} role="status">{msg}</p>}
        <button>Pledge</button>
      </form>
      <p className="tag mt">Live version: payments through a regulated provider (such as M-Pesa or card), receipts, and independent case verification.</p>
    </div>
  );
}
