'use client';
import { useState, useEffect, useRef } from 'react';
import { get, set, download } from '../../lib/store';
import { LANGS } from '../../lib/lang';
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
const fresh = (project) => ({ id: uid(), title: 'New chat', lang: 'English', msgs: [], at: Date.now(), project: project || null });
const SR = () => (typeof window !== 'undefined' ? window.SpeechRecognition || window.webkitSpeechRecognition : null);
const VL = { English: 'en-US', Kiswahili: 'sw-KE', French: 'fr-FR', Arabic: 'ar-SA', Spanish: 'es-ES', Somali: 'so-SO' };
async function shrink(file, max, quality) {
  const bmp = await createImageBitmap(file); const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s); c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  let q = quality, out = c.toDataURL('image/jpeg', q); while (out.length > 3000000 && q > 0.4) { q -= 0.15; out = c.toDataURL('image/jpeg', q); } return out;
}
const PLUGINS = [['/scan', '📷', 'Health scanner', 'Photos, labels, documents'], ['/search', '🔎', 'Trusted search', 'WHO, MoH, UNICEF, CDC'], ['/myth', '🧪', 'Myth or fact', 'Check a claim'], ['/emergency', '🚑', 'Emergency', 'Call 999 or 112'], ['/learn', '🎓', 'Learning center', 'Lessons and quizzes'], ['/quiz', '🎮', 'Quiz', 'Test yourself'], ['/relief', '🤝', 'Debt relief', 'Cases and donations'], ['/vault', '🗂️', 'File vault', 'Private files on this device'], ['/providers', '🏥', 'Providers', 'Clinics you saved'], ['/impact', '📊', 'Impact', 'Prototype metrics']];
function Sheet({ title, onClose, children }) {
  return (<div className="sheetbg" onClick={onClose}><div className="sheet" onClick={(e) => e.stopPropagation()} role="dialog" aria-label={title}><div className="sheethead"><h2>{title}</h2><button className="ico" aria-label="Close" onClick={onClose}>✕</button></div>{children}</div></div>);
}
export default function ChatPage() {
  const [chats, setChats] = useState([]); const [cur, setCur] = useState(null); const [ready, setReady] = useState(false);
  const [tmp, setTmp] = useState(fresh()); const [isTemp, setIsTemp] = useState(false);
  const [mode, setMode] = useState('chat'); const [sheet, setSheet] = useState(''); const [drawer, setDrawer] = useState(false); const [plus, setPlus] = useState(false);
  const [q, setQ] = useState(''); const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [find, setFind] = useState('');
  const [lib, setLib] = useState([]); const [imgs, setImgs] = useState([]); const [projects, setProjects] = useState([]); const [sched, setSched] = useState([]); const [toast, setToast] = useState('');
  const [provider, setProvider] = useState('auto'); const [name, setName] = useState('XE'); const [call, setCall] = useState(null); const [listening, setListening] = useState(false);
  const end = useRef(null); const fileRef = useRef(null); const camRef = useRef(null); const recRef = useRef(null); const callRef = useRef(false);

  useEffect(() => {
    let c = get('afya_chats', []); if (!c.length) c = [fresh()];
    const a = get('afya_chat_active', c[0].id); setChats(c); setCur(c.some((x) => x.id === a) ? a : c[0].id);
    setLib(get('emzy_library', [])); setImgs(get('emzy_images', [])); setProjects(get('emzy_projects', [])); setSched(get('emzy_sched', []));
    setProvider(get('emzy_provider', 'auto')); setName(get('emzy_initials', 'XE'));
    const t = new URLSearchParams(window.location.search).get('q'); if (t) setQ(t.slice(0, 800)); setReady(true);
  }, []);
  useEffect(() => { if (!ready) return; set('afya_chats', chats); if (cur) set('afya_chat_active', cur); }, [chats, cur, ready]);
  useEffect(() => { if (ready) { set('emzy_library', lib); set('emzy_projects', projects); set('emzy_sched', sched); set('emzy_provider', provider); } }, [lib, projects, sched, provider, ready]);
  useEffect(() => { try { set('emzy_images', imgs); } catch {} }, [imgs]);
  const chat = isTemp ? tmp : chats.find((c) => c.id === cur) || chats[0];
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [chat?.msgs.length, busy]);
  const say = (m) => { setToast(m); setTimeout(() => setToast(''), 2600); };

  // Scheduled reminders: checked while the app is open
  useEffect(() => {
    const t = setInterval(() => {
      const now = new Date(); const hm = now.toTimeString().slice(0, 5); const day = now.toISOString().slice(0, 10);
      setSched((list) => { let hit = false; const next = list.map((s) => { if (s.on && s.time === hm && s.last !== day && (!s.date || s.date === day)) { hit = true; say('⏰ ' + s.title); try { if (Notification.permission === 'granted') new Notification('EMZY reminder', { body: s.title }); } catch {} navigator.vibrate?.(200); return { ...s, last: day, on: s.repeat === 'daily' }; } return s; }); return hit ? next : list; });
    }, 20000); return () => clearInterval(t);
  }, []);

  const update = (id, fn) => (isTemp ? setTmp((c) => fn(c)) : setChats((cs) => cs.map((c) => (c.id === id ? fn(c) : c))));
  function newChat(project) { setIsTemp(false); const c = fresh(project); setChats((cs) => [c, ...cs]); setCur(c.id); setErr(''); setDrawer(false); setSheet(''); }
  function toggleTemp() { if (!isTemp) { setTmp(fresh()); setIsTemp(true); setSheet('temp'); } else { setIsTemp(false); } setDrawer(false); setErr(''); }
  function openChat(id) { setIsTemp(false); setCur(id); setDrawer(false); setSheet(''); }
  function remove(id) { if (!confirm('Delete this chat?')) return; const rest = chats.filter((c) => c.id !== id); const n = rest.length ? rest : [fresh()]; setChats(n); if (cur === id) setCur(n[0].id); }
  function exportChat() { download(`emzy-chat-${chat.id}.txt`, chat.msgs.map((m) => `${m.role === 'user' ? 'You' : 'EMZY'}: ${m.content}`).join('\n\n') || 'Empty chat', 'text/plain'); }
  const chatRef = useRef(null); chatRef.current = chat;
  const proj = chat && projects.find((p) => p.id === chat.project);

  async function ask(text, base, lang) {
    const chat = chatRef.current; const id = chat.id; let config = {}; try { config = JSON.parse(localStorage.getItem('afya_owner_cfg') || '{}'); } catch {}
    if (provider !== 'auto') { config.provider = provider; if (provider !== 'groq') delete config.model; }
    if (proj && proj.instructions) config.systemPrompt = ((config.systemPrompt || '') + '\nProject "' + proj.name + '" instructions: ' + proj.instructions).slice(0, 1500);
    const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: base.slice(-10).map(({ role, content }) => ({ role, content })), language: lang, config, memory: isTemp ? [] : get('emzy_memory', []), learn: get('emzy_learn', true), work: mode === 'work', forceWeb: mode === 'work' }) });
    const d = await r.json();
    if (d.needKey) { window.dispatchEvent(new Event('emzy-need-key')); throw Object.assign(new Error('Add an AI key in the box that opened, then send again.'), { key: true }); }
    if (!r.ok) throw new Error(d.error || 'Request failed');
    update(id, (c) => ({ ...c, msgs: [...base, { role: 'assistant', content: d.reply, urgent: d.urgent, fallback: d.fallback, reason: d.reason, sources: d.sources, provider: d.provider, ms: d.ms }], at: Date.now() }));
    return d.reply;
  }
  async function send(e, override) {
    e?.preventDefault(); const chat = chatRef.current; const text = (override ?? q).trim(); if (!text || !chat || (busy && override === undefined)) return;
    const rm = !isTemp && text.match(/^(?:remember|note)(?: that)?[: ]+(.+)/i); if (rm) set('emzy_memory', [...get('emzy_memory', []), rm[1].slice(0, 200)]);
    setErr(''); setBusy(true); setQ(''); const base = [...chat.msgs, { role: 'user', content: text }];
    update(chat.id, (c) => ({ ...c, msgs: base, title: c.msgs.length ? c.title : text.slice(0, 40), at: Date.now() }));
    try { return await ask(text, base, chat.lang); } catch (x) { if (x.key) { update(chat.id, (c) => ({ ...c, msgs: c.msgs.slice(0, -1) })); setQ(text); } setErr(x.message || 'Something went wrong.'); } finally { setBusy(false); }
  }
  async function sendPhoto(e) {
    const f = e.target.files?.[0]; e.target.value = ''; setPlus(false); if (!f || !chat) return; if (f.size > 25 * 1048576) return setErr('That photo is over 25 MB.');
    setErr(''); setBusy(true); const text = q.trim(); setQ('');
    try {
      const full = await shrink(f, 1280, 0.85), thumb = await shrink(f, 220, 0.6);
      const base = [...chat.msgs, { role: 'user', content: text || 'Please look at this photo.', img: thumb }];
      update(chat.id, (c) => ({ ...c, msgs: base, title: c.msgs.length ? c.title : '📷 Photo', at: Date.now() }));
      const r = await fetch('/api/scan', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ image: full, mode: 'other', question: text, language: chat.lang }) });
      const d = await r.json(); if (d.needKey) window.dispatchEvent(new Event('emzy-need-key')); if (!r.ok) throw new Error(d.error || 'Photo analysis failed.');
      update(chat.id, (c) => ({ ...c, msgs: [...base, { role: 'assistant', content: d.reply, provider: d.provider }] }));
      if (!isTemp) setImgs((l) => [{ id: uid(), thumb, reply: d.reply, at: Date.now() }, ...l].slice(0, 30));
    } catch (x) { setErr(x.message || 'This photo could not be read.'); } finally { setBusy(false); }
  }
  function dictate() {
    const R = SR(); if (!R) return setErr('Voice input is not supported in this browser. Type instead.');
    if (listening) { recRef.current?.stop(); return; }
    const r = new R(); recRef.current = r; r.lang = VL[chat.lang] || 'en-US'; r.interimResults = true;
    r.onresult = (ev) => setQ(Array.from(ev.results).map((x) => x[0].transcript).join(' ')); r.onerror = () => setErr('Could not hear you. Check microphone permission.'); r.onend = () => setListening(false); r.start(); setListening(true);
  }
  // Voice call: listen, ask, speak, repeat
  function speak(t, lang) { return new Promise((res) => { if (!('speechSynthesis' in window)) return res(); const u = new SpeechSynthesisUtterance(t.slice(0, 900)); u.lang = VL[lang] || 'en-US'; u.onend = res; u.onerror = res; speechSynthesis.cancel(); speechSynthesis.speak(u); }); }
  async function loop() {
    const R = SR(); if (!R) { setCall(null); callRef.current = false; return setErr('Voice calls need a browser with speech recognition (Chrome).'); }
    while (callRef.current) {
      setCall('Listening…'); const heard = await new Promise((res) => { const r = new R(); recRef.current = r; r.lang = VL[chat.lang] || 'en-US'; let t = ''; r.onresult = (e) => { t = e.results[0][0].transcript; }; r.onend = () => res(t); r.onerror = () => res(''); try { r.start(); } catch { res(''); } });
      if (!callRef.current) break; if (!heard) continue;
      setCall('Thinking…'); setBusy(true); let reply = ''; try { reply = await send(null, heard); } catch {} setBusy(false);
      if (reply && callRef.current) { setCall('Speaking…'); await speak(reply, chat.lang); }
    }
  }
  const startCall = () => { callRef.current = true; setCall('Starting…'); loop(); };
  const endCall = () => { callRef.current = false; setCall(null); try { recRef.current?.abort(); speechSynthesis.cancel(); } catch {} };
  const rate = (i, ok) => { const a = chat.msgs[i], u = chat.msgs[i - 1]; set('emzy_eval', [...get('emzy_eval', []), { q: u ? u.content.slice(0, 120) : '', a: a.content, ok, web: !!(a.sources && a.sources.length), fb: !!a.fallback, t: Date.now() }]); say(ok ? 'Thanks, saved.' : 'Thanks, noted.'); };
  const save = (m) => { setLib((l) => [{ id: uid(), text: m.content, at: Date.now() }, ...l]); say('Saved to Library'); };
  const shown = chats.filter((c) => !find || (c.title + c.msgs.map((m) => m.content).join(' ')).toLowerCase().includes(find.toLowerCase()));

  if (!ready || !chat) return <div className="cg" style={{ display: 'grid', placeItems: 'center' }}>Loading…</div>;
  return (
    <div className="cg">
      <div className="cg-top">
        <button className="ico" aria-label="Open menu" onClick={() => setDrawer(true)}>☰</button>
        {isTemp ? <span className="pill">Temporary chat</span> : <div className="seg" role="tablist"><button role="tab" aria-selected={mode === 'chat'} className={mode === 'chat' ? 'on' : ''} onClick={() => setMode('chat')}>Chat</button><button role="tab" aria-selected={mode === 'work'} className={mode === 'work' ? 'on' : ''} onClick={() => setMode('work')}>✦ Work</button></div>}
        <button className={'ico' + (isTemp ? ' on' : '')} aria-label="Temporary chat" aria-pressed={isTemp} onClick={toggleTemp}>🕶</button>
        <button className="ico" aria-label="New chat" onClick={() => newChat(chat.project)}>✎</button>
      </div>

      <div className="cg-body">
        {chat.msgs.length === 0 && <div className="cg-empty">{isTemp ? <><h2>Temporary chat</h2><p>This chat won’t appear in history or Library, and EMZY won’t remember it.</p></> : <><h2>{proj ? proj.name : mode === 'work' ? 'Work mode' : 'How can I help with your health questions?'}</h2><p>{mode === 'work' ? 'Longer, structured answers that check the web.' : 'Ask in English or Kiswahili. EMZY explains, your clinic decides.'}</p><div className="chips">{['What are the first signs of malaria?', 'How do I make water safe to drink?', 'Explain high blood pressure simply'].map((a) => <button key={a} className="chip" onClick={() => send(null, a)}>{a}</button>)}</div></>}</div>}
        {chat.msgs.map((m, i) => (
          <div key={i}>
            {m.urgent && <div className="urgentbar">This may be urgent. Call 999 or 112, or go to the nearest hospital now.</div>}
            <div className={`m ${m.role}${m.urgent ? ' urgent' : ''}`}>{m.img && <img className="thumb" src={m.img} alt="Your photo" />}{m.content}</div>
            {m.role === 'assistant' && <p className="tag meta">{m.provider && <span className="badge">{m.provider}{m.ms ? ` · ${m.ms}ms` : ''}</span>} {m.fallback ? `Offline guide${m.reason ? ` (${String(m.reason).slice(0, 60)})` : ''}. ` : ''}{m.sources && m.sources.length > 0 && <>Web: {m.sources.map((x, k) => <a key={k} href={x.url} target="_blank" rel="noreferrer">{x.src} </a>)}</>}<button className="mini" aria-label="Copy" onClick={() => { navigator.clipboard?.writeText(m.content); say('Copied'); }}>⧉</button><button className="mini" aria-label="Read aloud" onClick={() => speak(m.content, chat.lang)}>🔊</button>{!isTemp && <button className="mini" aria-label="Save to Library" onClick={() => save(m)}>🔖</button>}<button className="mini" aria-label="Helpful" onClick={() => rate(i, true)}>👍</button><button className="mini" aria-label="Not helpful" onClick={() => rate(i, false)}>👎</button> <a href={`/search?q=${encodeURIComponent((chat.msgs[i - 1]?.content || '').slice(0, 100))}`}>Verify</a></p>}
          </div>))}
        {busy && <div className="m assistant dots">Thinking…</div>}<div ref={end} />
      </div>
      {err && <p className="err cg-err" role="alert">{err}</p>}

      <form className="cg-bar" onSubmit={send}>
        {plus && <div className="plusmenu"><button type="button" onClick={() => camRef.current.click()}>📷 Take photo</button><button type="button" onClick={() => fileRef.current.click()}>🖼 Choose photo</button><button type="button" onClick={() => { setPlus(false); setSheet('plugins'); }}>🔌 Tools</button></div>}
        <input ref={fileRef} type="file" accept="image/*" hidden onChange={sendPhoto} /><input ref={camRef} type="file" accept="image/*" capture="environment" hidden onChange={sendPhoto} />
        <button type="button" className="ico" aria-label="Add" onClick={() => setPlus(!plus)}>＋</button>
        <input aria-label="Ask EMZY" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask EMZY" maxLength={800} />
        {q.trim() ? <button className="send" disabled={busy} aria-label="Send">↑</button> : <><button type="button" className={'ico' + (listening ? ' on' : '')} aria-label="Dictate" onClick={dictate}>🎙</button><button type="button" className="call" aria-label="Voice call" onClick={startCall}>📞</button></>}
      </form>

      {drawer && <div className="sheetbg left" onClick={() => setDrawer(false)}><aside className="drawer" onClick={(e) => e.stopPropagation()} aria-label="Menu">
        <div className="row" style={{ alignItems: 'center' }}><h2 style={{ margin: 0, flex: 1 }}>EMZY</h2><input aria-label="Search chats" placeholder="Search" value={find} onChange={(e) => setFind(e.target.value)} style={{ maxWidth: 140 }} /></div>
        {[['images', '🖼', 'Images'], ['library', '📚', 'Library'], ['projects', '📁', 'Projects'], ['sched', '⏰', 'Scheduled'], ['plugins', '🔌', 'Plugins']].map(([k, i, t]) => <button key={k} className="nav" onClick={() => { setSheet(k); setDrawer(false); }}>{i} {t}</button>)}
        <a className="nav" href="/">🏠 Home</a><button className="nav" onClick={() => { window.dispatchEvent(new Event('emzy-need-key')); setDrawer(false); }}>🔑 AI keys</button>
        <hr />
        <div className="hist">{shown.map((c) => <div key={c.id} className={'hrow' + (!isTemp && c.id === chat.id ? ' on' : '')}><button onClick={() => openChat(c.id)}>{c.project ? '📁 ' : ''}{c.title}</button><button className="mini" aria-label="Delete chat" onClick={() => remove(c.id)}>🗑</button></div>)}</div>
        <div className="drawfoot"><button className="newbtn" onClick={() => newChat()}>✎ Chat</button><button className="avatar" aria-label="Profile" onClick={() => { const n = prompt('Your initials', name); if (n) { setName(n.slice(0, 2).toUpperCase()); set('emzy_initials', n.slice(0, 2).toUpperCase()); } }}>{name}</button></div>
      </aside></div>}

      {sheet === 'temp' && <Sheet onClose={() => setSheet('')} title="Temporary chat"><p>This chat won’t appear in history, Library or memory. It disappears when you leave or start a new chat. Educational information only.</p><button onClick={() => setSheet('')}>Got it</button></Sheet>}

      {sheet === 'library' && <Sheet onClose={() => setSheet('')} title="Library">{!lib.length ? <p className="tag">Tap 🔖 under an answer to save it here.</p> : lib.map((l) => <details key={l.id}><summary>{l.text.slice(0, 60)}…</summary><div style={{ whiteSpace: 'pre-wrap' }}>{l.text}</div><div className="row mt"><button className="alt small" onClick={() => { navigator.clipboard?.writeText(l.text); say('Copied'); }}>Copy</button><button className="alt small" onClick={() => setLib(lib.filter((x) => x.id !== l.id))}>Remove</button></div></details>)}</Sheet>}

      {sheet === 'images' && <Sheet onClose={() => setSheet('')} title="Images"><p className="tag">Photos you scanned in chat. Only small thumbnails are kept on this device.</p><div className="igrid">{imgs.map((i) => <button key={i.id} className="ithumb" onClick={() => { newChat(); setTimeout(() => setSheet(''), 0); }} aria-label="Scanned photo"><img src={i.thumb} alt="Scanned" onClick={(e) => { e.stopPropagation(); alert(i.reply); }} /></button>)}</div>{!imgs.length && <p>No photos yet. Tap ＋ in chat to scan one.</p>}<a className="btn" href="/scan">Open full scanner</a></Sheet>}

      {sheet === 'projects' && <Sheet onClose={() => setSheet('')} title="Projects"><p className="tag">A project gives its chats shared instructions, for example “Answer for a school health club in Kiswahili”.</p>
        <form onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.target); const n = String(f.get('n') || '').trim(); if (!n) return; setProjects([...projects, { id: uid(), name: n.slice(0, 40), instructions: String(f.get('i') || '').slice(0, 500) }]); e.target.reset(); }}><input name="n" placeholder="Project name" maxLength={40} /><textarea name="i" placeholder="Instructions (optional)" rows={2} maxLength={500} /><button>Create project</button></form>
        {projects.map((p) => <div key={p.id} className="panel mt"><b>📁 {p.name}</b><p className="tag">{p.instructions || 'No instructions'}</p><div className="row"><button className="small" onClick={() => newChat(p.id)}>New chat here</button><button className="alt small" onClick={() => setProjects(projects.filter((x) => x.id !== p.id))}>Delete</button></div></div>)}</Sheet>}

      {sheet === 'sched' && <Sheet onClose={() => setSheet('')} title="Scheduled"><p className="tag">Health reminders (medicine time, clinic visit, handwashing). They ring while EMZY is open in your browser.</p>
        <form onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.target); const t = String(f.get('t') || '').trim(); if (!t) return; try { Notification.requestPermission(); } catch {} setSched([...sched, { id: uid(), title: t.slice(0, 80), time: f.get('h'), repeat: f.get('r'), on: true }]); e.target.reset(); }}><input name="t" placeholder="Reminder, e.g. Drink water" maxLength={80} /><div className="row"><input type="time" name="h" defaultValue="08:00" /><select name="r"><option value="daily">Every day</option><option value="once">Once</option></select></div><button>Add reminder</button></form>
        {sched.map((s) => <div key={s.id} className="panel mt row" style={{ alignItems: 'center' }}><span style={{ flex: 1 }}><b>{s.time}</b> {s.title}<br /><span className="tag">{s.repeat === 'daily' ? 'Daily' : 'Once'}{s.on ? '' : ' · done'}</span></span><button className="alt small" onClick={() => setSched(sched.filter((x) => x.id !== s.id))}>Remove</button></div>)}</Sheet>}

      {sheet === 'plugins' && <Sheet onClose={() => setSheet('')} title="Plugins"><label htmlFor="pv">AI provider</label><select id="pv" value={provider} onChange={(e) => setProvider(e.target.value)}><option value="auto">Auto (best available, with fallback)</option><option value="groq">Groq (fast)</option><option value="gemini">Gemini (photos, documents)</option><option value="openrouter">OpenRouter (any model)</option></select>
        <label htmlFor="lg">Answer language</label><select id="lg" value={chat.lang} onChange={(e) => update(chat.id, (c) => ({ ...c, lang: e.target.value }))}>{LANGS.map((l) => <option key={l}>{l}</option>)}</select>
        <div className="row mt"><button className="alt small" onClick={() => { const m = get('emzy_memory', []); const n = prompt('Memory (one fact per line):', m.join('\n')); if (n !== null) set('emzy_memory', n.split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 30)); }}>Memory</button><button className="alt small" onClick={exportChat}>Download chat</button></div>
        <div className="pgrid">{PLUGINS.map(([h, i, t, d]) => <a key={h} className="plug" href={h}><span style={{ fontSize: 22 }}>{i}</span><b>{t}</b><span className="tag">{d}</span></a>)}</div></Sheet>}

      {call && <div className="callbg" role="dialog" aria-label="Voice call"><div className="orb" /><h2>{call}</h2><p className="tag" style={{ color: '#cfe' }}>Speak naturally. EMZY answers out loud.</p><button className="hang" onClick={endCall}>End</button></div>}
      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}
