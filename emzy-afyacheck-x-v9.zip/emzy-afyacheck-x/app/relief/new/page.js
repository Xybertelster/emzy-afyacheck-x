'use client';
import { useState } from 'react';
import { get, set } from '../../../lib/store';
const CATS = ['Hospital bills', 'Maternal health', 'Child health', 'Medicines', 'Mental health', 'Other'];
export default function NewCase() {
  const [f, setF] = useState({ name: '', title: '', category: CATS[0], goal: '', place: '', story: '', proof: '', consent: false });
  const [err, setErr] = useState(''); const [ok, setOk] = useState(''); const u = (k, v) => setF({ ...f, [k]: v });
  async function submit(e) {
    e.preventDefault(); setErr(''); setOk('');
    try {
      const r = await fetch('/api/relief', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) });
      const d = await r.json(); if (!r.ok) throw new Error(d.error);
      set('afya_cases', [d, ...get('afya_cases', [])]); setOk(`Case ${d.id} saved on this device as "Awaiting review". See it in the marketplace.`);
      setF({ name: '', title: '', category: CATS[0], goal: '', place: '', story: '', proof: '', consent: false });
    } catch (x) { setErr(x.message || 'Could not submit.'); }
  }
  return (
    <div className="wrap pad" style={{ maxWidth: 680 }}>
      <h1>Submit a medical debt case</h1>
      <p className="notice" style={{ textAlign: 'left', borderRadius: 8 }}>Never enter ID numbers, bank details, card numbers or an M-Pesa PIN. Proof files are not uploaded in this prototype: only the file name is kept on your device.</p>
      <form onSubmit={submit} className="panel mt">
        <label htmlFor="n">Your name</label><input id="n" value={f.name} onChange={(e) => u('name', e.target.value)} maxLength={60} />
        <label htmlFor="t">Case title</label><input id="t" value={f.title} onChange={(e) => u('title', e.target.value)} maxLength={100} placeholder="e.g. Surgery bill for my mother" />
        <label htmlFor="c">Category</label><select id="c" value={f.category} onChange={(e) => u('category', e.target.value)}>{CATS.map((c) => <option key={c}>{c}</option>)}</select>
        <label htmlFor="g">Amount owed (KES)</label><input id="g" type="number" value={f.goal} onChange={(e) => u('goal', e.target.value)} />
        <label htmlFor="p">County or town (optional)</label><input id="p" value={f.place} onChange={(e) => u('place', e.target.value)} maxLength={60} />
        <label htmlFor="s">What happened?</label><textarea id="s" rows={5} value={f.story} onChange={(e) => u('story', e.target.value)} maxLength={800} />
        <label htmlFor="f">Bill or receipt (optional)</label><input id="f" type="file" accept="image/*,.pdf" onChange={(e) => u('proof', e.target.files?.[0]?.name || '')} />
        <label className="opt"><input type="checkbox" checked={f.consent} onChange={(e) => u('consent', e.target.checked)} /> I confirm this is true and I understand it is a prototype with no guaranteed funding.</label>
        {err && <p className="err" role="alert">{err}</p>}{ok && <p className="ok">{ok} <a href="/relief">Open marketplace</a></p>}
        <p><button>Submit case</button></p>
      </form>
    </div>
  );
}
