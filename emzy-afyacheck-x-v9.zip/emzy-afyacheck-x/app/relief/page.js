'use client';
import { useState, useEffect } from 'react';
import { get, set, SEED, KES, raisedFor } from '../../lib/store';
export default function Relief() {
  const [mine, setMine] = useState([]); const [pl, setPl] = useState([]);
  const [q, setQ] = useState(''); const [cat, setCat] = useState('All'); const [sort, setSort] = useState('need');
  const [open, setOpen] = useState(null); const [amt, setAmt] = useState(1000); const [who, setWho] = useState(''); const [anon, setAnon] = useState(false); const [msg, setMsg] = useState('');
  useEffect(() => { setMine(get('afya_cases', [])); setPl(get('afya_pledges', [])); }, []);
  const all = [...mine, ...SEED]; const cats = ['All', ...new Set(all.map((c) => c.category))];
  const list = all.filter((c) => (cat === 'All' || c.category === cat) && (c.title + c.story).toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => sort === 'need' ? (b.goal - raisedFor(b, pl)) - (a.goal - raisedFor(a, pl)) : sort === 'close' ? (raisedFor(b, pl) / b.goal) - (raisedFor(a, pl) / a.goal) : b.goal - a.goal);
  function pledge(c) {
    const a = Math.round(+amt);
    if (!(a >= 50)) return setMsg('Enter at least KES 50.');
    if (!anon && who.trim().length < 2) return setMsg('Enter your name or choose anonymous.');
    const p = { id: Date.now().toString(36), caseId: c.id, amount: a, name: anon ? 'Anonymous' : who.trim().slice(0, 60), at: new Date().toISOString() };
    const n = [p, ...pl]; setPl(n); set('afya_pledges', n); setMsg(`Pledge of ${KES(a)} recorded for this case. No money was collected.`);
  }
  return (
    <div className="wrap pad">
      <h1>Debt relief marketplace</h1>
      <p className="notice" style={{ textAlign: 'left', borderRadius: 8 }}>Prototype. Pledges are simulated: no money moves, nothing is guaranteed, and cases marked Demo are fictional. A live version needs a database, case verification, and a regulated payment provider.</p>
      <p className="row mt"><a className="btn" href="/relief/new">Submit a medical debt case</a><a className="btn alt" href="/donate">Become a donor</a></p>
      <div className="row mt">
        <input aria-label="Search cases" placeholder="Search cases" value={q} onChange={(e) => setQ(e.target.value)} />
        <select aria-label="Category" value={cat} onChange={(e) => setCat(e.target.value)}>{cats.map((c) => <option key={c}>{c}</option>)}</select>
        <select aria-label="Sort" value={sort} onChange={(e) => setSort(e.target.value)}><option value="need">Most still needed</option><option value="close">Closest to goal</option><option value="goal">Largest goal</option></select>
      </div>
      {list.length === 0 && <p className="empty mt">No cases match. Clear the search or submit a new case.</p>}
      <div className="grid mt">{list.map((c) => { const r = raisedFor(c, pl), pct = Math.min(100, Math.round((r / c.goal) * 100)); return (
        <div className="panel" key={c.id}>
          <span className="badge">{c.status}</span><h3 style={{ marginTop: '.4rem' }}>{c.title}</h3>
          <p className="tag">{c.category} · {c.name}{c.place ? ` · ${c.place}` : ''}</p><p>{c.story}</p>
          <div className="bar" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}><i style={{ width: pct + '%' }} /></div>
          <p className="tag">{KES(r)} of {KES(c.goal)} ({pct}%)</p>
          {open === c.id ? (
            <div><label htmlFor={'a' + c.id}>Amount (KES)</label><input id={'a' + c.id} type="number" min="50" value={amt} onChange={(e) => setAmt(e.target.value)} />
              <label htmlFor={'w' + c.id}>Your name</label><input id={'w' + c.id} value={who} onChange={(e) => setWho(e.target.value)} disabled={anon} />
              <label className="opt"><input type="checkbox" checked={anon} onChange={(e) => setAnon(e.target.checked)} /> Give anonymously</label>
              {msg && <p className={msg.startsWith('Pledge') ? 'ok' : 'err'} role="status">{msg}</p>}
              <div className="row"><button onClick={() => pledge(c)}>Confirm pledge</button><button className="alt" onClick={() => { setOpen(null); setMsg(''); }}>Close</button></div></div>
          ) : <button onClick={() => { setOpen(c.id); setMsg(''); }}>Pledge to this case</button>}
        </div>); })}</div>
    </div>
  );
}
