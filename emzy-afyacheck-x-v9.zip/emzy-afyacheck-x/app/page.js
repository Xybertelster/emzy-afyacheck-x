import AiStatus from '../components/AiStatus';
const GO = [['/scan', 'Scan a photo'], ['/learn', 'Learn'], ['/myth', 'Myth or fact?'], ['/search', 'Trusted search'], ['/relief', 'Debt relief'], ['/donate', 'Donate'], ['/relief/new', 'Submit a case'], ['/vault', 'My file vault'], ['/tools', 'Health tools'], ['/quiz', 'Quiz'], ['/emergency', 'Emergency'], ['/leaderboard', 'Donor board'], ['/dashboard', 'My dashboard']];
const ASK = ['What are the first signs of malaria?', 'How do I make water safe to drink?', 'Explain high blood pressure simply', 'How can I support a friend who feels low?', 'What should I ask my doctor before a test?'];
export default function Home() {
  return (
    <div className="wrap pad">
      <section style={{ maxWidth: 760 }}>
        <p><AiStatus /></p>
        <h1>Understand your health information before you act on it.</h1>
        <p className="lede">Ask in your own language, check answers against WHO, Kenya Ministry of Health, UNICEF and CDC, then learn the basics. EMZY explains. Your clinic decides.</p>
        <a href="/chat" className="btn big">Open EMZY Chat</a>
        <a href="/scan" className="btn alt" style={{ display: 'block', textAlign: 'center', padding: '1rem' }}>Scan a photo: skin, medicine, wound</a>
        <p className="tag">Your chats are saved on this device so you can come back to them.</p>
      </section>
      <h2 className="mt">Try asking</h2>
      <div className="row">{ASK.map((a) => <a key={a} className="btn alt" style={{ flex: '1 1 220px', fontWeight: 600 }} href={`/chat?q=${encodeURIComponent(a)}`}>{a}</a>)}</div>
      <h2 className="mt">Everything in one place</h2>
      <div className="grid">{GO.map(([h, t]) => <a key={h} className="btn tile" href={h}>{t}</a>)}</div>
    </div>
  );
}
