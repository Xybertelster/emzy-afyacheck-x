'use client';
import { useEffect, useRef, useState } from 'react';
const N = 20;
export default function Snake() {
  const cv = useRef(null); const st = useRef({}); const ts = useRef(null);
  const [score, setScore] = useState(0); const [best, setBest] = useState(0); const [over, setOver] = useState(false); const [run, setRun] = useState(false);
  const reset = () => { st.current = { s: [[10, 10], [9, 10], [8, 10]], d: [1, 0], nd: [1, 0], f: [15, 10], sc: 0 }; setScore(0); setOver(false); };
  useEffect(() => { try { setBest(+localStorage.getItem('snake_best') || 0); } catch {} reset(); }, []);
  const turn = (x, y) => { const g = st.current; if (!g.d || (g.d[0] === -x && g.d[1] === -y)) return; g.nd = [x, y]; setRun(true); };
  useEffect(() => {
    const k = (e) => { const m = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0], w: [0, -1], s: [0, 1], a: [-1, 0], d: [1, 0] }[e.key]; if (m) { e.preventDefault(); turn(...m); } };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, []);
  useEffect(() => {
    const draw = () => { const c = cv.current; if (!c) return; const x = c.getContext('2d'), z = c.width / N, g = st.current; x.fillStyle = '#0c1613'; x.fillRect(0, 0, c.width, c.height); x.fillStyle = '#F2B705'; x.fillRect(g.f[0] * z + 2, g.f[1] * z + 2, z - 4, z - 4); g.s.forEach((p, i) => { x.fillStyle = i ? '#6FD3A8' : '#fff'; x.fillRect(p[0] * z + 1, p[1] * z + 1, z - 2, z - 2); }); };
    draw(); if (!run || over) return;
    const t = setInterval(() => {
      const g = st.current; g.d = g.nd; const h = [g.s[0][0] + g.d[0], g.s[0][1] + g.d[1]];
      if (h[0] < 0 || h[1] < 0 || h[0] >= N || h[1] >= N || g.s.some((p) => p[0] === h[0] && p[1] === h[1])) { setOver(true); setRun(false); setBest((b) => { const n = Math.max(b, g.sc); try { localStorage.setItem('snake_best', n); } catch {} return n; }); return; }
      g.s.unshift(h);
      if (h[0] === g.f[0] && h[1] === g.f[1]) { g.sc++; setScore(g.sc); do { g.f = [Math.floor(Math.random() * N), Math.floor(Math.random() * N)]; } while (g.s.some((p) => p[0] === g.f[0] && p[1] === g.f[1])); } else g.s.pop();
      draw();
    }, Math.max(60, 140 - st.current.sc * 3));
    return () => clearInterval(t);
  }, [run, over]);
  return (<div className="wrap pad"><h1>Snake</h1><p className="lede">Works with no internet after you have opened this page once online. Arrow keys, WASD, swipe or the buttons.</p>
    <p><b>Score {score}</b> · Best {best}</p>
    <canvas ref={cv} width={400} height={400} style={{ width: '100%', maxWidth: 400, borderRadius: 12, touchAction: 'none' }} onTouchStart={(e) => { ts.current = [e.touches[0].clientX, e.touches[0].clientY]; }} onTouchEnd={(e) => { if (!ts.current) return; const dx = e.changedTouches[0].clientX - ts.current[0], dy = e.changedTouches[0].clientY - ts.current[1]; if (Math.abs(dx) > Math.abs(dy)) turn(dx > 0 ? 1 : -1, 0); else turn(0, dy > 0 ? 1 : -1); }} />
    {over && <p className="err">Game over.</p>}
    <div className="row mt" style={{ maxWidth: 400 }}><button type="button" onClick={() => turn(0, -1)}>↑</button><button type="button" onClick={() => turn(-1, 0)}>←</button><button type="button" onClick={() => turn(0, 1)}>↓</button><button type="button" onClick={() => turn(1, 0)}>→</button></div>
    <div className="row mt" style={{ maxWidth: 400 }}><button type="button" className="alt" onClick={() => setRun(!run)}>{run ? 'Pause' : 'Start / Resume'}</button><button type="button" className="alt" onClick={() => { reset(); setRun(false); }}>Restart</button></div></div>);
}
