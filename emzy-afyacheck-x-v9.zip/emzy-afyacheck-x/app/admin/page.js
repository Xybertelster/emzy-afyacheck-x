'use client';
import { useState, useEffect } from 'react';
export default function Admin() {
  const [pw, setPw] = useState(''); const [key, setKey] = useState(''); const [prov, setProv] = useState('groq'); const [st, setSt] = useState(null); const [msg, setMsg] = useState(''); const [fb, setFb] = useState([]);
  const load = () => fetch('/api/admin').then((r) => r.json()).then(setSt);
  useEffect(() => { load(); }, []);
  async function call(body) { const r = await fetch('/api/admin', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-admin': pw }, body: JSON.stringify(body) }); const d = await r.json(); setMsg(d.error || 'Done.'); load(); }
  async function loadFb() { const r = await fetch('/api/feedback', { headers: { 'x-admin': pw } }); const d = await r.json(); if (d.items) setFb(d.items); else setMsg(d.error); }
  return (<div className="wrap pad"><h1>Admin</h1>
    <div className="panel"><p>{st ? (st.hasKey ? 'Shared keys active (' + Object.entries(st.providers||{}).filter(([,v])=>v).map(([k])=>k).join(', ') + '): visitors are never asked.' : 'No shared key yet: visitors are asked for their own.') : 'Checking…'}</p>
      <p className="tag">Storage: {st && st.storage ? 'connected' : 'not connected'} · Admin password: {st && st.adminConfigured ? 'set' : 'missing (set ADMIN_PASSWORD in Vercel)'}</p>
      <input type="password" placeholder="Admin password" value={pw} onChange={(e) => setPw(e.target.value)} />
      <select value={prov} onChange={(e) => setProv(e.target.value)}><option value="groq">Groq</option><option value="gemini">Gemini</option><option value="openrouter">OpenRouter</option></select><input type="password" placeholder="API key" value={key} onChange={(e) => setKey(e.target.value)} />
      <div className="row"><button onClick={() => call({ key, provider: prov })}>Save key for everyone</button><button onClick={() => call({ clear: true, provider: prov })}>Remove shared key</button><button onClick={loadFb}>Load feedback</button></div>
      {msg && <p role="status">{msg}</p>}</div>
    {fb.map((f, i) => <div className="panel" key={i}><b>{f.type}</b> {f.rating ? '★'.repeat(f.rating) : ''} <span className="tag">{new Date(f.t).toLocaleString()} · {f.page}</span><p>{f.text}</p></div>)}</div>);
}
