import { NextResponse } from 'next/server';
import { kv, kvReady, adminOk } from '../../../lib/kv';
import { allKeys, getStats } from '../../../lib/ai';
export const runtime = 'nodejs';
export async function GET(req) {
  const ks = await allKeys(); const hasKey = Object.values(ks).some(Boolean);
  return NextResponse.json({ hasKey, providers: Object.fromEntries(Object.entries(ks).map(([p, k]) => [p, !!k])), stats: adminOk(req) ? getStats() : undefined, storage: kvReady(), adminConfigured: !!process.env.ADMIN_PASSWORD, authed: adminOk(req) });
}
export async function POST(req) {
  if (!process.env.ADMIN_PASSWORD) return NextResponse.json({ error: 'Set ADMIN_PASSWORD in Vercel environment variables first.' }, { status: 400 });
  if (!adminOk(req)) return NextResponse.json({ error: 'Wrong admin password.' }, { status: 401 });
  if (!kvReady()) return NextResponse.json({ error: 'No storage connected. In Vercel: Storage → Create Upstash Redis → connect to this project, then redeploy. Or set GROQ_API_KEY instead.' }, { status: 400 });
  const b = await req.json().catch(() => ({}));
  const p = ['groq', 'gemini', 'openrouter'].includes(b.provider) ? b.provider : 'groq';
  if (b.clear) { await kv(['DEL', 'emzy_key_' + p]); return NextResponse.json({ ok: true, cleared: true }); }
  const k = String(b.key || '').trim().replace(/^bearer\s+/i, '');
  if (k.length < 12) return NextResponse.json({ error: 'That key looks too short.' }, { status: 400 });
  await kv(['SET', 'emzy_key_' + p, k]);
  return NextResponse.json({ ok: true });
}
