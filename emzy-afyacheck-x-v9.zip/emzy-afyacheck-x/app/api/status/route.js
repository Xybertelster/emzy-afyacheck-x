import { NextResponse } from 'next/server';
import { allKeys, checkProviders, getStats, PROVIDERS } from '../../../lib/ai';
export const dynamic = 'force-dynamic';
export const maxDuration = 30;
let cache = null;
export async function GET(req) {
  const keys = await allKeys(); const test = new URL(req.url).searchParams.get('test');
  const configured = PROVIDERS.filter((p) => keys[p]);
  const base = { ai: configured.length > 0, configured, stats: getStats() };
  if (!configured.length || !test) return NextResponse.json(base);
  const sig = configured.join() + configured.map((p) => keys[p].slice(-6)).join();
  if (!cache || cache.sig !== sig || Date.now() - cache.t > 45000) cache = { sig, t: Date.now(), v: await checkProviders() };
  const providers = cache.v; const live = Object.values(providers).some((x) => x.live);
  return NextResponse.json({ ...base, providers, live, reason: live ? '' : Object.values(providers).map((x) => x.reason).filter(Boolean)[0] || '' });
}
