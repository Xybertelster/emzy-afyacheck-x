import { NextResponse } from 'next/server';
import { LANGS, BASE_PROMPT } from '../../../lib/lang';
import { aiChat } from '../../../lib/ai';
export const maxDuration = 30;
export async function POST(req) {
  let b; try { b = await req.json(); } catch { return NextResponse.json({ error: 'Invalid request.' }, { status: 400 }); }
  const claim = String(b.claim || '').trim().slice(0, 600);
  if (claim.length < 8) return NextResponse.json({ error: 'Paste a health claim (at least 8 characters).' }, { status: 400 });
  const lang = LANGS.includes(b.language) ? b.language : 'English';
  const offline = (reason) => NextResponse.json({ verdict: 'Unclear', explanation: 'Live AI did not assess this claim. Check it on WHO and the Kenya Ministry of Health using Trusted search.', fallback: true, reason });
  const res = await aiChat({ json: true, temperature: 0.1, max: 500,
    messages: [{ role: 'system', content: `${BASE_PROMPT}\nYou assess health claims. Return JSON only: {"verdict":"True"|"False"|"Misleading"|"Unclear","explanation":"2-4 plain sentences in ${lang}, saying what is known, what is uncertain, and which trusted source to check"}. Use Unclear when evidence is weak.` }, { role: 'user', content: claim }] });
  if (!res.ok) return offline(res.reason);
  try { const j = JSON.parse(res.text.replace(/```json|```/g, '').trim()); return NextResponse.json({ verdict: ['True', 'False', 'Misleading', 'Unclear'].includes(j.verdict) ? j.verdict : 'Unclear', explanation: String(j.explanation || '').slice(0, 900) }); } catch { return offline('Unreadable AI answer'); }
}
