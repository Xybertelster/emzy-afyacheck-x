import { NextResponse } from 'next/server';
import { kv, kvReady, adminOk } from '../../../lib/kv';
export const runtime = 'nodejs';
export async function POST(req) {
  const b = await req.json().catch(() => ({}));
  const item = { t: Date.now(), type: ['bug', 'idea', 'praise', 'rating'].includes(b.type) ? b.type : 'idea', rating: Math.min(5, Math.max(0, +b.rating || 0)), text: String(b.text || '').slice(0, 1000), page: String(b.page || '').slice(0, 80) };
  if (!item.text && !item.rating) return NextResponse.json({ error: 'Write something or pick a rating.' }, { status: 400 });
  if (kvReady()) { await kv(['LPUSH', 'emzy_feedback', JSON.stringify(item)]); await kv(['LTRIM', 'emzy_feedback', 0, 499]); }
  return NextResponse.json({ ok: true, stored: kvReady() });
}
export async function GET(req) {
  if (!adminOk(req)) return NextResponse.json({ error: 'Admin only.' }, { status: 401 });
  const r = (await kv(['LRANGE', 'emzy_feedback', 0, 199])) || [];
  return NextResponse.json({ items: r.map((x) => { try { return JSON.parse(x); } catch { return null; } }).filter(Boolean) });
}
