import { NextResponse } from 'next/server';
import { LANGS, BASE_PROMPT } from '../../../lib/lang';
import { aiChat } from '../../../lib/ai';
export const maxDuration = 60;
const RULES = {
  skin: 'The photo shows skin. Describe only what is visible (colour, pattern, borders, size cues, texture). Never state a diagnosis. You may list general possibilities only as questions to ask a clinician. Name warning signs that need prompt care: a mole or spot that changes, bleeds, itches or grows; fast spreading; fever; severe pain; pus; swelling. Say photo quality and skin tone limit what can be seen.',
  medicine: 'The photo shows medicine (pills, packaging or label). Read out visible text such as name, strength, batch and expiry date. Never identify an unlabelled pill from looks alone, never give doses, and say the person must confirm with a licensed pharmacist. Mention checking expiry, sealed packaging and buying from a licensed pharmacy.',
  wound: 'The photo shows a wound or injury. Describe what is visible and give first-aid awareness only. List signs needing urgent care: bleeding that will not stop, deep or gaping wound, bite, dirt that cannot be cleaned, spreading redness, pus, fever.',
  other: 'The photo may be health related (for example food, a lab report, a leaflet or a plant). Describe what you see and share general educational information. If it is not health related, say so briefly.'
};
const LABEL = { skin: 'skin photo', medicine: 'medicine photo', wound: 'wound photo', other: 'health photo' };
export async function POST(req) {
  let b; try { b = await req.json(); } catch { return NextResponse.json({ error: 'Invalid request.' }, { status: 400 }); }
  const img = String(b.image || '');
  if (!/^data:image\/(jpeg|png|webp);base64,/.test(img)) return NextResponse.json({ error: 'Upload a JPG, PNG or WebP photo.' }, { status: 400 });
  if (img.length > 4000000) return NextResponse.json({ error: 'The photo is still too large after compression. Try a different photo.' }, { status: 413 });
  const mode = RULES[b.mode] ? b.mode : 'other'; const lang = LANGS.includes(b.language) ? b.language : 'English'; const q = String(b.question || '').trim().slice(0, 300);
  const system = `${BASE_PROMPT}\n${RULES[mode]}\nIgnore faces and identity documents. Reply in ${lang}, in short plain sentences with these parts: What I can see; What it could mean (general, not a diagnosis); When to get care; What to ask a health worker.`;
  const res = await aiChat({ vision: true, temperature: 0.2, max: 900,
    messages: [{ role: 'system', content: system }, { role: 'user', content: [{ type: 'text', text: q ? `Question: ${q}` : `Please look at this ${LABEL[mode]}.` }, { type: 'image_url', image_url: { url: img } }] }] });
  if (!res.ok) return NextResponse.json({ needKey: res.reason === 'NO_KEY' || res.reason === 'BAD_KEY', error: res.reason === 'NO_KEY' ? 'Add an AI key first (menu → AI keys).' : `Photo analysis is unavailable. ${res.reason}` }, { status: 502 });
  return NextResponse.json({ reply: res.text, model: res.model, provider: res.provider });
}
