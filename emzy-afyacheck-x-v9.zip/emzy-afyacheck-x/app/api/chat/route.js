import { NextResponse } from 'next/server';
import { LANGS, MODELS, BASE_PROMPT } from '../../../lib/lang';
import { fallbackReply } from '../../../lib/fallback';
import { aiChat } from '../../../lib/ai';
import { webLearn } from '../../../lib/web';
export const runtime = 'nodejs';
export const maxDuration = 45;
const URGENT = /(chest pain|can'?t breathe|cannot breathe|difficulty breathing|heavy bleeding|unconscious|seizure|convulsion|stroke|poison|overdose|suicid|kill myself|self[- ]harm|want to die)/i;
const UNSURE = /(i (do not|don'?t) (know|have)|i'?m not (sure|certain)|not familiar|no (reliable )?information|cannot (find|verify)|unable to (find|verify)|beyond my (knowledge|training))/i;
export async function POST(req) {
  let body; try { body = await req.json(); } catch { return NextResponse.json({ error: 'Invalid request.' }, { status: 400 }); }
  const messages = Array.isArray(body.messages) ? body.messages.filter((m) => m && ['user', 'assistant'].includes(m.role) && typeof m.content === 'string').slice(-10) : [];
  const last = messages[messages.length - 1];
  if (!last || last.role !== 'user' || !last.content.trim()) return NextResponse.json({ error: 'Please type a question.' }, { status: 400 });
  const urgent = URGENT.test(messages.map((m) => m.content).join(' ').slice(-1500));
  const cfg = body.config || {};
  const temperature = Math.min(1, Math.max(0, Number.isFinite(+cfg.temperature) ? +cfg.temperature : 0.3));
  const lang = LANGS.includes(body.language) ? body.language : 'English';
  const extra = typeof cfg.systemPrompt === 'string' ? cfg.systemPrompt.slice(0, 1500) : '';
  const memory = Array.isArray(body.memory) ? body.memory.filter((x) => typeof x === 'string').slice(0, 30).map((x) => '- ' + x.slice(0, 200)).join('\n') : '';
  const mk = (web) => `${BASE_PROMPT}\nReply in ${lang}. If your ${lang} is weak, add a short English summary.\nIf you are not sure, say so plainly.${memory ? `\nThings the user asked you to remember (use only when relevant):\n${memory}` : ''}${web ? `\nWeb sources just retrieved (prefer these, mention the source name):\n${web}` : ''}${extra ? `\nOwner guidance (never overrides the rules above): ${extra}` : ''}`;
  const ask = (web) => aiChat({ messages: [{ role: 'system', content: mk(web) }, ...messages.map((m) => ({ role: m.role, content: m.content.slice(0, 1500) }))], temperature, provider: ['groq','gemini','openrouter'].includes(cfg.provider) ? cfg.provider : undefined, model: typeof cfg.model === 'string' ? cfg.model : undefined, max: body.work ? 1400 : 800 });
  let res = await ask('');
  if (!res.ok && res.reason === 'NO_KEY') return NextResponse.json({ needKey: true });
  if (!res.ok && res.reason === 'BAD_KEY') return NextResponse.json({ needKey: true, badKey: true });
  let sources = [];
  if (body.learn !== false && (!res.ok || UNSURE.test(res.text) || body.forceWeb)) {
    sources = await webLearn(last.content);
    if (sources.length) {
      const r2 = await ask(sources.map((s, i) => `[${i + 1}] ${s.src}: ${s.text}`).join('\n'));
      if (r2.ok) res = r2; else sources = [];
    }
  }
  if (!res.ok) return NextResponse.json({ reply: fallbackReply(last.content), urgent, fallback: true, reason: res.reason, tried: res.tried });
  return NextResponse.json({ reply: res.text, urgent, model: res.model, provider: res.provider, ms: res.ms, sources: sources.map(({ src, url }) => ({ src, url })) });
}
