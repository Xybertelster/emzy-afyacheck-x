import { NextResponse } from 'next/server';
export async function GET(req) {
  const q = (new URL(req.url).searchParams.get('q') || '').trim().slice(0, 200);
  if (!q) return NextResponse.json({ error: 'Enter a health topic to search.' }, { status: 400 });
  const e = encodeURIComponent;
  const site = (s) => `https://www.google.com/search?q=${e(`${q} site:${s}`)}`;
  return NextResponse.json({
    query: q,
    links: [
      { name: 'Google (all web)', url: `https://www.google.com/search?q=${e(q)}`, note: 'Broad results. Compare with the trusted sources below.' },
      { name: 'World Health Organization', url: site('who.int'), note: 'Global guidance and fact sheets.' },
      { name: 'Kenya Ministry of Health', url: site('health.go.ke'), note: 'National guidelines and campaigns.' },
      { name: 'UNICEF', url: site('unicef.org'), note: 'Child and family health.' },
      { name: 'CDC', url: site('cdc.gov'), note: 'Disease prevention and public-health data.' }
    ]
  });
}
