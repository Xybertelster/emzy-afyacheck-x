import { NextResponse } from 'next/server';
import { randomUUID } from 'crypto';
const CATS = ['Hospital bills', 'Maternal health', 'Child health', 'Medicines', 'Mental health', 'Other'];
export async function POST(req) {
  let b; try { b = await req.json(); } catch { return NextResponse.json({ error: 'Invalid request.' }, { status: 400 }); }
  const name = String(b.name || '').trim(), title = String(b.title || '').trim(), story = String(b.story || '').trim(), goal = Math.round(+b.goal);
  if (name.length < 2) return NextResponse.json({ error: 'Enter your name (at least 2 characters).' }, { status: 400 });
  if (title.length < 6) return NextResponse.json({ error: 'Give the case a short title (at least 6 characters).' }, { status: 400 });
  if (!CATS.includes(b.category)) return NextResponse.json({ error: 'Choose a category.' }, { status: 400 });
  if (!(goal >= 1000 && goal <= 5000000)) return NextResponse.json({ error: 'Amount must be between KES 1,000 and KES 5,000,000.' }, { status: 400 });
  if (story.length < 20) return NextResponse.json({ error: 'Explain the situation (at least 20 characters).' }, { status: 400 });
  if (!b.consent) return NextResponse.json({ error: 'Please confirm the statement at the bottom.' }, { status: 400 });
  return NextResponse.json({ id: randomUUID().slice(0, 8).toUpperCase(), title: title.slice(0, 100), category: b.category, name: name.slice(0, 60), place: String(b.place || '').slice(0, 60), goal, raised: 0, story: story.slice(0, 800), proof: String(b.proof || '').slice(0, 120), status: 'Awaiting review', createdAt: new Date().toISOString() });
}
