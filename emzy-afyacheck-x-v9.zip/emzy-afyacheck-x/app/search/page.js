'use client';
import { useState, useEffect } from 'react';
export default function Search() {
  const [q, setQ] = useState(''); const [res, setRes] = useState(null); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  useEffect(() => { const t = new URLSearchParams(window.location.search).get('q'); if (t) setQ(t.slice(0, 200)); }, []);
  async function go(e) {
    e.preventDefault(); setErr(''); setRes(null); setBusy(true);
    try { const r = await fetch(`/api/search?q=${encodeURIComponent(q)}`); const d = await r.json(); if (!r.ok) throw new Error(d.error); setRes(d); }
    catch (x) { setErr(x.message || 'Search failed.'); } finally { setBusy(false); }
  }
  return (
    <div className="wrap" style={{ padding: '2rem 1rem' }}>
      <h1>Trusted search</h1>
      <p className="lede">Check a claim in more than one place. Open the broad search, then compare with WHO, Kenya MoH, UNICEF and CDC.</p>
      <form onSubmit={go} className="row"><input aria-label="Health topic or claim" value={q} onChange={(e) => setQ(e.target.value)} placeholder="e.g. malaria prevention for children" /><button disabled={busy}>Search</button></form>
      {err && <p className="err" role="alert">{err}</p>}
      {res && <div className="grid" style={{ marginTop: '1rem' }}>{res.links.map((l) => (
        <div className="panel" key={l.name}><h3>{l.name}</h3><p>{l.note}</p><a className="btn alt" href={l.url} target="_blank" rel="noopener noreferrer">Open results</a></div>))}</div>}
      <h2 style={{ marginTop: '2rem' }}>Quick verification checklist</h2>
      <ul><li>Who published it, and when?</li><li>Does WHO or the Ministry of Health say the same?</li><li>Does it promise a cure or ask for money? Be careful.</li><li>Still unsure? Ask a health worker.</li></ul>
    </div>
  );
}
