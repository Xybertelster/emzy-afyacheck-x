'use client';
import { useState, useEffect } from 'react';
import { get, set } from '../../lib/store';
const Q = [
  ['What does WHO advise for babies in the first 6 months?', ['Water and porridge', 'Exclusive breastfeeding', 'Cow\u2019s milk'], 1],
  ['You have a fever in a malaria area. Best step?', ['Take leftover pills', 'Wait a week', 'Get tested promptly at a clinic'], 2],
  ['How long should you wash hands with soap?', ['About 20 seconds', '2 seconds', 'Not needed if hands look clean'], 0],
  ['Chest pain and trouble breathing. What now?', ['Sleep it off', 'Call 999 or 112, or go to hospital now', 'Search online first'], 1],
  ['A post promises a miracle cure if you pay. What do you do?', ['Share it quickly', 'Buy it', 'Check WHO or the Ministry of Health first'], 2],
  ['First aid for a burn?', ['Toothpaste', 'Pop the blisters', 'Cool under running water for about 20 minutes'], 2]
];
export default function Quiz() {
  const [a, setA] = useState({}); const [done, setDone] = useState(false); const [best, setBest] = useState(null);
  useEffect(() => setBest(get('afya_quiz', null)), []);
  const score = Q.filter((q, i) => a[i] === q[2]).length;
  function finish() { if (Object.keys(a).length < Q.length) return; setDone(true); if (best == null || score > best) { set('afya_quiz', score); setBest(score); } }
  return (
    <div className="wrap pad" style={{ maxWidth: 680 }}><h1>Health literacy quiz</h1>{best != null && <p className="tag">Your best score: {best}/{Q.length}</p>}
      {Q.map(([t, o, c], i) => (
        <fieldset key={i} className="panel mt" style={{ border: '1px solid var(--line)' }}><legend><b>{i + 1}. {t}</b></legend>
          {o.map((x, j) => <label key={j} className="opt"><input type="radio" name={'q' + i} disabled={done} checked={a[i] === j} onChange={() => setA({ ...a, [i]: j })} /> {x}{done && j === c ? ' (correct)' : ''}</label>)}</fieldset>))}
      {!done ? <p><button onClick={finish} disabled={Object.keys(a).length < Q.length}>See my score</button></p> :
        <div className="panel mt"><p className="stat">{score}/{Q.length}</p><span className="badge">{score >= 5 ? 'Health Champion' : score >= 3 ? 'Health Learner' : 'Getting started'}</span><p>Review the <a href="/learn">Learning Center</a> to improve.</p><button onClick={() => { setA({}); setDone(false); }}>Try again</button></div>}
    </div>
  );
}
