'use client';
import { useState, useEffect } from 'react';
import { get, set, KES, download, fmtSize, BACKUP_KEYS } from '../../lib/store';
import { listFiles } from '../../lib/db';
const ACC = 'afya_owner_account', CFG = 'afya_owner_cfg', SES = 'afya_owner_session';
const MODELS = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant'];
async function hash(pw, salt) { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(salt + pw)); return Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, '0')).join(''); }
export default function Owner() {
  const [acc, setAcc] = useState(null); const [authed, setAuthed] = useState(false); const [ready, setReady] = useState(false);
  const [email, setEmail] = useState(''); const [pw, setPw] = useState(''); const [err, setErr] = useState(''); const [ok, setOk] = useState('');
  const [cfg, setCfg] = useState({ model: MODELS[0], temperature: 0.3, systemPrompt: '' });
  const [cases, setCases] = useState([]); const [st, setSt] = useState({}); const [ai, setAi] = useState(null); const [test, setTest] = useState(''); const [bk, setBk] = useState('');
  const refresh = async () => {
    setCases(get('afya_cases', []));
    let fs = [], vb = 0; try { fs = (await listFiles()) || []; vb = fs.reduce((a, f) => a + f.size, 0); } catch {}
    setSt({ chats: get('afya_chats', []).length, pledges: get('afya_pledges', []), files: fs.length, vb });
  };
  useEffect(() => {
    try { setAcc(JSON.parse(localStorage.getItem(ACC) || 'null')); setCfg((c) => ({ ...c, ...JSON.parse(localStorage.getItem(CFG) || '{}') })); setAuthed(sessionStorage.getItem(SES) === '1'); } catch {}
    setReady(true);
  }, []);
  useEffect(() => { if (authed) { refresh(); fetch('/api/status').then((r) => r.json()).then(setAi).catch(() => setAi({ ai: false })); } }, [authed]);
  async function create(e) { e.preventDefault(); setErr(''); if (!/^\S+@\S+\.\S+$/.test(email)) return setErr('Enter a valid email.'); if (pw.length < 8) return setErr('Use a password of at least 8 characters.'); const salt = crypto.randomUUID(); const a = { email, salt, hash: await hash(pw, salt) }; localStorage.setItem(ACC, JSON.stringify(a)); sessionStorage.setItem(SES, '1'); setAcc(a); setAuthed(true); setPw(''); }
  async function login(e) { e.preventDefault(); setErr(''); if (email.trim().toLowerCase() !== acc.email.toLowerCase() || (await hash(pw, acc.salt)) !== acc.hash) return setErr('Email or password is incorrect.'); sessionStorage.setItem(SES, '1'); setAuthed(true); setPw(''); }
  function save(e) { e.preventDefault(); set(CFG, cfg); setOk('AI settings saved on this device.'); }
  function logout() { sessionStorage.removeItem(SES); setAuthed(false); }
  function review(id, status) { const n = cases.map((c) => (c.id === id ? { ...c, status } : c)); set('afya_cases', n); setCases(n); }
  function removeCase(id) { if (!confirm('Delete this case?')) return; const n = cases.filter((c) => c.id !== id); set('afya_cases', n); setCases(n); }
  async function testAi() { setTest('Testing…'); try { const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: 'Say hello in five words.' }], language: 'English', config: cfg }) }); const d = await r.json(); setTest(d.fallback ? `Offline guide answered. Reason: ${d.reason || 'unknown'}. Link GROQ_API_KEY to the project and redeploy, or fix the key.` : `Live AI works (${d.model}): ${d.reply}`); } catch { setTest('Test failed. Check your connection.'); } }
  function exportAll() { const o = { app: 'emzy-afyacheck-x', at: new Date().toISOString() }; BACKUP_KEYS.forEach((k) => { o[k] = get(k, null); }); download('emzy-backup.json', JSON.stringify(o, null, 2)); }
  async function importAll(e) { const f = e.target.files?.[0]; e.target.value = ''; if (!f) return; try { const o = JSON.parse(await f.text()); if (o.app !== 'emzy-afyacheck-x') throw new Error(); let n = 0; BACKUP_KEYS.forEach((k) => { if (o[k] != null) { set(k, o[k]); n++; } }); setBk(`Restored ${n} data set(s).`); refresh(); } catch { setBk('That is not a valid EMZY backup file.'); } }
  if (!ready) return null;
  if (!authed) return (
    <div className="wrap pad" style={{ maxWidth: 560 }}><h1>Owner control center</h1>
      <form onSubmit={acc ? login : create} className="panel"><h2>{acc ? 'Owner login' : 'Create owner account'}</h2>
        <label htmlFor="e">Email</label><input id="e" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" />
        <label htmlFor="p">Password</label><input id="p" type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete={acc ? 'current-password' : 'new-password'} />
        {err && <p className="err" role="alert">{err}</p>}<p><button>{acc ? 'Log in' : 'Create account'}</button></p>
        <p className="tag">Prototype: the account lives in this browser only. The Groq key stays on the server.</p></form></div>
  );
  const pledged = (st.pledges || []).reduce((a, p) => a + p.amount, 0);
  return (
    <div className="wrap pad"><div className="row" style={{ alignItems: 'center' }}><h1 style={{ flex: 1 }}>Owner control center</h1><button className="alt" onClick={logout}>Log out</button></div>
      <div className="grid">
        <div className="panel"><p className="stat">{cases.length}</p><p>Cases on this device</p></div><div className="panel"><p className="stat">{KES(pledged)}</p><p>{(st.pledges || []).length} simulated pledge(s)</p></div>
        <div className="panel"><p className="stat">{st.chats ?? 0}</p><p>Saved chats</p></div><div className="panel"><p className="stat">{st.files ?? 0}</p><p>Vault files ({fmtSize(st.vb || 0)})</p></div></div>
      <div className="grid mt">
        <div className="panel"><h2>AI connection</h2><p>{ai == null ? 'Checking…' : ai.ai ? <span className="ok">Server key found. Default model: {ai.model}</span> : <span className="err">No server key found for this deployment.</span>}</p><button onClick={testAi}>Test live AI</button>{test && <p role="status">{test}</p>}</div>
        <form onSubmit={save} className="panel"><h2>AI settings</h2><label htmlFor="mo">Model</label><select id="mo" value={cfg.model} onChange={(e) => setCfg({ ...cfg, model: e.target.value })}>{MODELS.map((m) => <option key={m}>{m}</option>)}</select>
          <label htmlFor="t">Temperature: {cfg.temperature}</label><input id="t" type="range" min="0" max="1" step="0.1" value={cfg.temperature} onChange={(e) => setCfg({ ...cfg, temperature: +e.target.value })} />
          <label htmlFor="s">Extra instructions</label><textarea id="s" rows={4} maxLength={1500} value={cfg.systemPrompt} onChange={(e) => setCfg({ ...cfg, systemPrompt: e.target.value })} />
          <p className="tag">Built-in safety rules always apply.</p>{ok && <p className="ok">{ok}</p>}<button>Save settings</button></form></div>
      <h2 className="mt">Review cases</h2>
      {cases.length === 0 ? <p className="empty">No submitted cases yet.</p> : <div className="grid">{cases.map((c) => <div className="panel" key={c.id}><span className="badge">{c.status}</span><h3>{c.title}</h3><p className="tag">{c.name} · {KES(c.goal)} · {c.category}</p><div className="row"><button className="small" onClick={() => review(c.id, 'Approved (prototype)')}>Approve</button><button className="alt small" onClick={() => review(c.id, 'Needs more info')}>Need info</button><button className="alt small" onClick={() => review(c.id, 'Rejected')}>Reject</button><button className="alt small" onClick={() => removeCase(c.id)}>Delete</button></div></div>)}</div>}
      <p className="tag">Reviews change this device only. A live version needs a shared database and real verification.</p>
      <div className="panel mt"><h2>Backup and restore</h2><p>Download chats, cases, pledges and settings as one file, or restore from one. Vault files are not included because they can be very large.</p><div className="row"><button onClick={exportAll}>Download backup</button><label className="btn alt" style={{ flex: '0 0 auto', cursor: 'pointer' }}>Restore backup<input type="file" accept="application/json,.json" onChange={importAll} style={{ display: 'none' }} /></label></div>{bk && <p role="status">{bk}</p>}</div>
    </div>
  );
}
