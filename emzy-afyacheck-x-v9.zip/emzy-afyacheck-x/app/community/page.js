const R = [
  ['Emergency numbers (Kenya)', 'Police/ambulance 999 or 112. Kenya Red Cross 1199. Childline 116. Gender violence helpline 1195. Confirm locally; numbers can change.'],
  ['Run a 15-minute talk', 'Pick one topic from My learning. Share its four steps, ask two questions, end with where to get care.'],
  ['Handwashing demo', 'Soap, water, 20 seconds. Have each person practise once.'],
  ['School health club ideas', 'Weekly myth-or-fact game using the Myth check page. Track progress together.'],
  ['Community health volunteers', 'Share the Trusted search page so claims are checked against WHO, MoH, UNICEF and CDC.'],
  ['Official sources', 'Kenya Ministry of Health (health.go.ke), WHO (who.int), UNICEF, CDC.']
];
export const metadata = { title: 'Community | EMZY AfyaCheck X' };
export default function Community() {
  return (<div className="wrap pad"><h1>Community education</h1><p className="lede">Simple resources for groups, schools and volunteers.</p>
    <div className="grid">{R.map(([t, d]) => <div className="panel" key={t}><h3>{t}</h3><p>{d}</p></div>)}</div></div>);
}
