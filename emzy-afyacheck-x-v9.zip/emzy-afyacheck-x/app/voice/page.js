'use client';
import { useState } from 'react';
const L = { English: 'en-US', Kiswahili: 'sw-KE' };
export default function Voice() {
  const [lang, setLang] = useState('English'); const [heard, setHeard] = useState(''); const [reply, setReply] = useState(''); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  async function ask(text) {
    setBusy(true); setMsg('');
    try { const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: text }], language: lang }) }); const d = await r.json();
      if (d.needKey) { window.dispatchEvent(new Event('emzy-need-key')); setMsg('Add an AI key first.'); } else { setReply(d.reply || ''); if ('speechSynthesis' in window && d.reply) { const u = new SpeechSynthesisUtterance(d.reply); u.lang = L[lang]; speechSynthesis.cancel(); speechSynthesis.speak(u); } } } catch { setMsg('Could not reach EMZY.'); }
    setBusy(false);
  }
  function listen() { const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) { setMsg('Voice input is not supported in this browser. Type below instead.'); return; } const r = new SR(); r.lang = L[lang]; r.onresult = (e) => { const t = e.results[0][0].transcript; setHeard(t); ask(t); }; r.onerror = () => setMsg('Could not hear you. Check microphone permission.'); r.onend = () => setMsg((m) => (m === 'Listening…' ? '' : m)); r.start(); setMsg('Listening…'); }
  return (<div className="wrap pad"><h1>Voice assistant</h1><p className="lede">Speak a health question and hear the answer. Uses your browser's speech support.</p>
    <select value={lang} onChange={(e) => setLang(e.target.value)}>{Object.keys(L).map((l) => <option key={l}>{l}</option>)}</select>
    <div className="row mt"><button type="button" onClick={listen} disabled={busy}>🎤 Speak</button><button type="button" className="alt" onClick={() => window.speechSynthesis && speechSynthesis.cancel()}>Stop voice</button></div>
    <input className="mt" placeholder="Or type here and press Enter" onKeyDown={(e) => { if (e.key === 'Enter' && e.target.value.trim()) { setHeard(e.target.value); ask(e.target.value); e.target.value = ''; } }} />
    {msg && <p role="status">{msg}</p>}{heard && <p><b>You:</b> {heard}</p>}{busy && <p>Thinking…</p>}{reply && <div className="panel"><p style={{ whiteSpace: 'pre-wrap' }}>{reply}</p></div>}</div>);
}
