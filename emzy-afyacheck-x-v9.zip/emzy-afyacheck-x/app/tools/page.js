'use client';
import { useState } from 'react';
export default function Tools() {
  const [h, setH] = useState(''); const [w, setW] = useState(''); const [lmp, setLmp] = useState('');
  const bmi = h > 0 && w > 0 ? w / ((h / 100) ** 2) : null;
  const cat = bmi == null ? '' : bmi < 18.5 ? 'Below the usual healthy range' : bmi < 25 ? 'Within the usual healthy range' : bmi < 30 ? 'Above the usual healthy range' : 'Well above the usual healthy range';
  let due = ''; if (lmp) { const d = new Date(lmp); if (!isNaN(d)) { d.setDate(d.getDate() + 280); due = d.toDateString(); } }
  return (
    <div className="wrap pad"><h1>Health tools</h1><p className="lede">Simple estimates for learning. They do not replace a health worker.</p>
      <div className="grid">
        <div className="panel"><h2>BMI (adults)</h2><label htmlFor="h">Height (cm)</label><input id="h" type="number" value={h} onChange={(e) => setH(e.target.value)} /><label htmlFor="w">Weight (kg)</label><input id="w" type="number" value={w} onChange={(e) => setW(e.target.value)} />
          {bmi && <p className="mt"><b>BMI {bmi.toFixed(1)}</b>: {cat}. BMI is only a rough screen. Ask a health worker what it means for you.</p>}</div>
        <div className="panel"><h2>Estimated due date</h2><label htmlFor="l">First day of last period</label><input id="l" type="date" value={lmp} onChange={(e) => setLmp(e.target.value)} />
          {due && <p className="mt"><b>About {due}</b>. This is an estimate. Attend antenatal care for confirmed dates.</p>}</div>
        <div className="panel"><h2>Before you visit a clinic</h2><ul><li>When did symptoms start, and are they getting worse?</li><li>List medicines you already take.</li><li>Write your questions down.</li><li>Ask what to watch for and when to return.</li></ul></div>
      </div></div>
  );
}
