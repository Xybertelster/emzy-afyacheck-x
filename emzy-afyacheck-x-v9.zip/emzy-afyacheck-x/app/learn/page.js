const TOPICS = [
  ['Malaria', 'Spread by infected Anopheles mosquito bites.', ['Sleep under an insecticide-treated net.', 'Fever in a malaria area: get tested promptly. Do not guess the medicine.', 'Pregnant women and young children should seek care early.']],
  ['Nutrition', 'A varied diet supports growth, immunity and energy.', ['Mix staples, vegetables, fruit, and protein such as beans, eggs, fish or meat.', 'WHO advises exclusive breastfeeding for the first 6 months.', 'Wash fruit and vegetables and store food covered.']],
  ['Hygiene', 'Clean hands stop many infections.', ['Wash hands with soap and water after the toilet and before eating or cooking.', 'Cover coughs and sneezes with your elbow.', 'Keep nails short and clean.']],
  ['Sanitation and water', 'Safe water and toilets prevent diarrhoea and cholera.', ['Boil, filter or chlorinate drinking water if unsure of the source.', 'Use a latrine or toilet and keep it clean.', 'Diarrhoea: keep drinking fluids and seek care if it is severe or lasts.']],
  ['Mental wellbeing', 'Mind and body health are connected.', ['Talk to someone you trust. Sleep, movement and routine help.', 'Persistent sadness, panic or worry deserve professional support.', 'Thoughts of self-harm: call 999 or 112 or go to the nearest hospital now.']],
  ['Adolescent health', 'Puberty brings physical and emotional change.', ['Ask a trusted adult or health worker. Questions are normal.', 'Ask a clinic about recommended vaccines such as HPV.', 'Respect and consent matter in every relationship.']],
  ['First-aid awareness', 'Quick, calm steps can reduce harm until help arrives.', ['Heavy bleeding: press firmly on the wound with a clean cloth and get help.', 'Burns: cool under running water for about 20 minutes. No toothpaste or oil.', 'Call 999 or 112 for breathing trouble, chest pain, seizures or loss of consciousness.']]
];
export const metadata = { title: 'Learning Center | EMZY AfyaCheck X' };
export default function Learn() {
  return (
    <div className="wrap" style={{ padding: '2rem 1rem' }}>
      <h1>Learning Center</h1>
      <p className="lede">Learn the basics first. Then ask EMZY to explain anything unclear, and verify it in <a href="/search">Trusted search</a>.</p>
      <div className="grid" style={{ gridTemplateColumns: '1fr' }}>
        {TOPICS.map(([t, s, pts]) => (
          <details key={t}><summary>{t}</summary><p>{s}</p><ul>{pts.map((p) => <li key={p}>{p}</li>)}</ul>
            <a href={`/?q=${encodeURIComponent(t)}`}>Ask EMZY about {t.toLowerCase()}</a></details>
        ))}
      </div>
      <p className="tag">General education only. See a qualified health worker for personal advice.</p>
    </div>
  );
}
