export const metadata = { title: 'Impact | EMZY AfyaCheck X' };
export default function Impact() {
  return (
    <div className="wrap" style={{ padding: '2rem 1rem' }}>
      <h1>Impact and approach</h1>
      <h2>The problem</h2><p>People struggle to tell what is trustworthy, what a term means, and when to seek care.</p>
      <h2>The solution</h2><p>One entry point: ask, understand, verify, learn, then take the right next step.</p>
      <h2>Responsible AI</h2><ul><li>Educational only: no diagnosis, no prescriptions.</li><li>Admits uncertainty and escalates emergencies.</li><li>Server-side AI: the Groq key is never exposed in the browser.</li><li>No patient database: settings and requests stay on the device.</li></ul>
      <h2>Where it grows</h2><p>More languages and health campaigns, verified facilities, partner-reviewed relief, and professional referrals, with other countries added by configuration.</p>
    </div>
  );
}
