export const metadata = { title: 'Privacy | EMZY AfyaCheck X' };
export default function Privacy() {
  return (
    <div className="wrap pad" style={{ maxWidth: 680 }}><h1>Privacy and safety</h1>
      <ul><li>No account or patient database. Quiz scores, cases, pledges and owner settings stay in your browser. Delete them any time from the dashboard.</li>
        <li>Questions you ask the AI are sent to Groq through our server to produce an answer. Do not type ID numbers, passwords or payment details.</li>
        <li>Chats are saved in this browser. Vault files are stored in this browser only and never uploaded.</li>
        <li>Photos you scan are sent to the AI service to be analysed and are not stored by this app. Do not include faces or ID documents.</li>
        <li>Pledges are simulated. No money is collected and no funding is guaranteed.</li>
        <li>Because data stays on one device, cases and pledges are not shared between people yet. A live version would add a database and case verification.</li>
        <li>Educational information only. Not a diagnosis, prescription or substitute for a health worker.</li></ul></div>
  );
}
