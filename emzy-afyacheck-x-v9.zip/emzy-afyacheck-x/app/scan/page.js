'use client';
import { useState, useEffect } from 'react';
import { get, set } from '../../lib/store';
import { LANGS } from '../../lib/lang';
const MODES = [['skin', 'Skin'], ['medicine', 'Medicine'], ['wound', 'Wound or injury'], ['other', 'Other health photo']];
const MAXFILE = 25 * 1024 * 1024;
async function compress(file) {
  const bmp = await createImageBitmap(file); const s = Math.min(1, 1280 / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s); c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
  let q = 0.85, out = c.toDataURL('image/jpeg', q); while (out.length > 3000000 && q > 0.4) { q -= 0.15; out = c.toDataURL('image/jpeg', q); } return out;
}
export default function Scan() {
  const [mode, setMode] = useState('skin'); const [lang, setLang] = useState('English'); const [q, setQ] = useState(''); const [img, setImg] = useState(''); const [info, setInfo] = useState('');
  const [res, setRes] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false); const [hist, setHist] = useState([]);
  useEffect(() => setHist(get('afya_scans', [])), []);
  async function pick(e) {
    const f = e.target.files?.[0]; e.target.value = ''; setErr(''); setRes(''); if (!f) return;
    if (f.size > MAXFILE) return setErr('That photo is over 25 MB. Choose a smaller one.');
    try { setImg(await compress(f)); setInfo(`${(f.size / 1048576).toFixed(1)} MB photo, shrunk for sending`); } catch { setErr('This photo format is not supported. Use a JPG or PNG photo.'); }
  }
  async function analyse() {
    if (!img) return setErr('Choose or take a photo first.'); setErr(''); setRes(''); setBusy(true);
    try {
      const r = await fetch('/api/scan', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ image: img, mode, question: q, language: lang }) });
      const d = await r.json(); if (!r.ok) throw new Error(d.error || 'Analysis failed.'); setRes(d.reply);
      const h = [{ id: Date.now().toString(36), mode, at: Date.now(), reply: d.reply }, ...hist].slice(0, 20); setHist(h); set('afya_scans', h);
    } catch (x) { setErr(x.message || 'Analysis failed.'); } finally { setBusy(false); }
  }
  const label = MODES.find((m) => m[0] === mode)[1];
  return (
    <div className="wrap pad" style={{ maxWidth: 720 }}><h1>Scan a photo</h1>
      <p className="notice" style={{ textAlign: 'left', borderRadius: 8 }}>For learning only. This cannot diagnose skin problems or confirm what a medicine is. Do not include faces or ID documents. The photo is sent to the AI to be analysed and this app does not store it.</p>
      <div className="panel mt">
        <label htmlFor="m">What is in the photo?</label><select id="m" value={mode} onChange={(e) => setMode(e.target.value)}>{MODES.map(([v, t]) => <option key={v} value={v}>{t}</option>)}</select>
        <label htmlFor="f">Take or choose a photo (up to 25 MB)</label><input id="f" type="file" accept="image/*" onChange={pick} />
        {img && <p className="mt"><img className="preview" src={img} alt="Your photo preview" /><br /><span className="tag">{info}</span></p>}
        <label htmlFor="q">Question (optional)</label><input id="q" value={q} onChange={(e) => setQ(e.target.value)} maxLength={300} placeholder="e.g. What does the label say?" />
        <label htmlFor="l">Answer language</label><select id="l" value={lang} onChange={(e) => setLang(e.target.value)}>{LANGS.map((l) => <option key={l}>{l}</option>)}</select>
        {err && <p className="err" role="alert">{err}</p>}<p><button onClick={analyse} disabled={busy}>{busy ? 'Analysing…' : 'Analyse photo'}</button></p>
      </div>
      {res && <div className="panel mt"><h2>Result</h2><div style={{ whiteSpace: 'pre-wrap' }}>{res}</div>
        <p className="row mt"><a className="btn" href={`/search?q=${encodeURIComponent(label + ' ' + q)}`}>Search trusted sources</a><a className="btn alt" href={`/chat?q=${encodeURIComponent(`I scanned a ${label.toLowerCase()} photo. The result said: ${res.slice(0, 300)} What should I ask a health worker?`)}`}>Discuss in EMZY Chat</a></p></div>}
      {hist.length > 0 && <><h2 className="mt">Recent results</h2><div className="grid" style={{ gridTemplateColumns: '1fr' }}>{hist.slice(0, 5).map((h) => <details key={h.id}><summary>{MODES.find((m) => m[0] === h.mode)?.[1]} · {new Date(h.at).toLocaleString()}</summary><div style={{ whiteSpace: 'pre-wrap' }}>{h.reply}</div></details>)}</div></>}
    </div>
  );
}
