'use client';
import { useState, useEffect } from 'react';
import { get, set, KES } from '../../lib/store';
export default function Dash() {
  const [d, setD] = useState({ q: null, cases: [], pl: [] });
  const load = () => setD({ q: get('afya_quiz', null), cases: get('afya_cases', []), pl: get('afya_pledges', []) });
  useEffect(load, []);
  function wipe() { if (!confirm('Delete all data saved on this device?')) return; ['afya_quiz', 'afya_cases', 'afya_pledges', 'afya_owner_cfg', 'afya_chats', 'afya_chat_active'].forEach((k) => localStorage.removeItem(k)); load(); }
  const total = d.pl.reduce((a, p) => a + p.amount, 0);
  return (
    <div className="wrap pad"><h1>My dashboard</h1><p className="lede">Everything below is stored only in this browser.</p>
      <div className="grid"><div className="panel"><p className="stat">{d.q == null ? '–' : `${d.q}/6`}</p><p>Best quiz score</p><a href="/quiz">Take the quiz</a></div>
        <div className="panel"><p className="stat">{d.cases.length}</p><p>Cases you submitted</p><a href="/relief/new">Submit a case</a></div>
        <div className="panel"><p className="stat">{KES(total)}</p><p>Pledged in {d.pl.length} pledge(s)</p><a href="/donate">Donate</a></div></div>
      <p className="mt"><button className="alt" onClick={wipe}>Delete my data on this device</button></p></div>
  );
}
