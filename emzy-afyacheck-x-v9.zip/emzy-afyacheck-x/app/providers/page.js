'use client';
import { useState, useEffect } from 'react';
import { get, set } from '../../lib/store';
export default function Providers() {
  const [list, setList] = useState([]); const [ok, setOk] = useState(false); const [q, setQ] = useState(''); const [f, setF] = useState({ name: '', place: '', type: 'Clinic', phone: '' });
  useEffect(() => { setList(get('emzy_providers', [])); setOk(true); }, []);
  useEffect(() => { if (ok) set('emzy_providers', list); }, [list, ok]);
  const add = (e) => { e.preventDefault(); if (!f.name.trim()) return; setList([...list, { ...f, id: Date.now() }]); setF({ name: '', place: '', type: 'Clinic', phone: '' }); };
  const shown = list.filter((p) => (p.name + p.place + p.type).toLowerCase().includes(q.toLowerCase()));
  return (<div className="wrap pad"><h1>Provider directory</h1><p className="lede">Save clinics you use or know. Always verify a facility before relying on it.</p>
    <div className="panel"><h3>Verify officially</h3><ul><li><a href="https://kmhfl.health.go.ke" target="_blank" rel="noreferrer">Kenya Master Health Facility List</a></li><li><a href="https://kmpdc.go.ke" target="_blank" rel="noreferrer">Kenya Medical Practitioners and Dentists Council</a></li><li><a href="https://www.google.com/maps/search/hospital+near+me" target="_blank" rel="noreferrer">Find nearby on Maps</a></li></ul></div>
    <form className="panel mt" onSubmit={add}><h3>Add a provider (saved on this device)</h3><input placeholder="Name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /><input placeholder="Town or county" value={f.place} onChange={(e) => setF({ ...f, place: e.target.value })} /><select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option>Clinic</option><option>Hospital</option><option>Pharmacy</option><option>Lab</option></select><input placeholder="Phone (optional)" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /><button>Add</button></form>
    <input className="mt" placeholder="Search saved providers" value={q} onChange={(e) => setQ(e.target.value)} />
    <div className="grid mt">{shown.map((p) => <div className="panel" key={p.id}><h3>{p.name}</h3><p>{p.type} · {p.place}</p>{p.phone && <a className="btn" href={'tel:' + p.phone}>Call</a>} <button type="button" className="alt" onClick={() => setList(list.filter((x) => x.id !== p.id))}>Remove</button></div>)}</div></div>);
}
