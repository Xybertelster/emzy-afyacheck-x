'use client';
import { useState, useEffect } from 'react';
import { get, tier, KES } from '../../lib/store';
const T = [['Friend', 'Any amount', 'Name on the donor board'], ['Supporter', 'KES 500+', 'Supporter badge'], ['Champion', 'KES 5,000+', 'Champion badge and impact note'], ['Patron', 'KES 50,000+', 'Patron badge and case spotlight'], ['Millionaire Circle', 'KES 1,000,000+', 'Top of the board and named fund']];
export default function Donors() {
  const [p, setP] = useState([]); useEffect(() => setP(get('afya_pledges', [])), []);
  const total = p.reduce((a, x) => a + x.amount, 0);
  const by = {}; p.forEach((x) => { const n = x.anon ? 'Anonymous' : x.name || 'Friend'; by[n] = (by[n] || 0) + x.amount; });
  const top = Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 10);
  return (<div className="wrap pad"><div className="hero2"><h1>Donor Hub</h1><p>Every pledge clears a real medical bill. Total pledged on this device: <b>{KES(total)}</b></p><a className="btn" href="/relief">Pick a case</a> <a className="btn" href="/donate">Give now</a></div>
    <h2>Giving tiers</h2><div className="grid">{T.map(([n, a, b]) => <div className="panel" key={n}><h3>{n}</h3><p>{a}</p><p className="tag">{b}</p></div>)}</div>
    <h2>Top donors</h2><div className="panel">{top.length ? <ol>{top.map(([n, v]) => <li key={n}>{n}: {KES(v)} ({tier(v)})</li>)}</ol> : <p>No pledges yet. Be the first.</p>}</div></div>);
}
