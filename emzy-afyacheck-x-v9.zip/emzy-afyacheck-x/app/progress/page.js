'use client';
import { useState, useEffect } from 'react';
import { TOPICS, SEASON } from '../../lib/topics';
import { get, set } from '../../lib/store';
export default function Progress() {
  const [done, setDone] = useState({}); const [ok, setOk] = useState(false);
  useEffect(() => { setDone(get('emzy_progress', {})); setOk(true); }, []);
  useEffect(() => { if (ok) set('emzy_progress', done); }, [done, ok]);
  const cnt = (t) => t.steps.filter((_, i) => done[t.id + i]).length;
  const total = TOPICS.reduce((a, t) => a + t.steps.length, 0), got = TOPICS.reduce((a, t) => a + cnt(t), 0);
  const next = TOPICS.filter((t) => cnt(t) < t.steps.length).sort((a, b) => (SEASON.ids.includes(b.id) ? 1 : 0) - (SEASON.ids.includes(a.id) ? 1 : 0)).slice(0, 3);
  return (<div className="wrap pad"><h1>My learning</h1><p className="lede">{got} of {total} steps done ({Math.round((got / total) * 100)}%). Saved on this device.</p>
    <div className="panel"><h3>Suggested next</h3><p className="tag">{SEASON.name}: {SEASON.note}</p>{next.length ? <ul>{next.map((t) => <li key={t.id}>{t.t}{SEASON.ids.includes(t.id) ? ' (seasonal)' : ''} · <a href={'/chat?q=' + encodeURIComponent('Explain ' + t.t + ' in simple terms.')}>Ask EMZY</a></li>)}</ul> : <p>All topics complete. Try the <a href="/quiz">quiz</a>.</p>}</div>
    <div className="grid mt">{TOPICS.map((t) => <div className="panel" key={t.id}><h3>{t.t} ({cnt(t)}/{t.steps.length})</h3>
      {t.steps.map((s, i) => <label key={i} style={{ fontWeight: 400 }}><input type="checkbox" style={{ width: 'auto' }} checked={!!done[t.id + i]} onChange={(e) => setDone({ ...done, [t.id + i]: e.target.checked })} /> {s}</label>)}</div>)}</div>
    <p><button type="button" className="alt" onClick={() => { if (confirm('Reset progress?')) setDone({}); }}>Reset progress</button></p></div>);
}
