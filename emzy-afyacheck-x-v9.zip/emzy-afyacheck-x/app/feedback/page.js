'use client';
import { useState } from 'react';
export default function Feedback() {
  const [type, setType] = useState('idea'); const [rating, setRating] = useState(0); const [text, setText] = useState(''); const [msg, setMsg] = useState('');
  async function go(e) { e.preventDefault(); const r = await fetch('/api/feedback', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type, rating, text, page: document.referrer.replace(location.origin, '') }) }); const d = await r.json(); if (d.ok) { setMsg('Thank you. Your feedback was received.'); setText(''); setRating(0); } else setMsg(d.error); }
  return (<div className="wrap pad"><h1>Feedback</h1><p className="lede">Tell us what works, what is broken, or what to build next.</p>
    <form className="panel" onSubmit={go}><label>Type</label><select value={type} onChange={(e) => setType(e.target.value)}><option value="idea">Idea</option><option value="bug">Bug</option><option value="praise">Praise</option></select>
      <label>Rating</label><div className="row">{[1, 2, 3, 4, 5].map((n) => <button type="button" key={n} aria-label={n + ' stars'} onClick={() => setRating(n)}>{n <= rating ? '★' : '☆'}</button>)}</div>
      <label>Message</label><textarea rows={5} maxLength={1000} value={text} onChange={(e) => setText(e.target.value)} /><button>Send feedback</button>{msg && <p role="status">{msg}</p>}</form></div>);
}
