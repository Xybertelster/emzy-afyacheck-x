const F = {
  'New in v8': 'Offline Snake game|Snake swipe and button controls|Snake best score|Offline page caching|Topic completion tracking|Seasonal suggestions|Personalized next-topic list|Health campaign pages|Community education resources|Printable community page|Provider directory (your own entries)|Official facility verification links|Voice assistant (speech in and out)|Kiswahili voice option|Answer-rating buttons|Answer quality dashboard|Key prompt on first open',
  'New in v6': 'Shared Groq key for all visitors|Admin page with password|Key validated before saving|Key stored in Upstash Redis|Visitor key prompt only when no shared key|Feedback page|Star ratings|Feedback types (idea, bug, praise)|Admin feedback inbox|Donor Hub page|Five giving tiers explained|Top-donor ranking|Hero banner styling|Card hover motion|Chat message animation|Web learning from Wikipedia|Web learning from DuckDuckGo|Source links on web answers|User memory notes|Remember-that command|Search across all chats|Copy answer button|Search-web button per answer',
  'AI and intelligence': 'Groq health assistant|11 answer languages|Follow-up conversation memory|Plain-language replies|Uncertainty-aware prompt|No-diagnosis rule|No-prescription rule|Urgent-symptom detection and warning|Offline guide fallback|Myth-or-fact claim checker|Four-way verdict (True, False, Misleading, Unclear)|Server-side API key|Configurable model|Configurable temperature|Configurable owner instructions|Locked safety rules|Input validation|Loading and error states',
  'Learning and literacy': 'Learning Center with 7 topics|Malaria prevention|Nutrition|Hygiene|Sanitation and water|Mental wellbeing|Adolescent health|First-aid awareness|Ask-EMZY link from each topic|Six-question quiz|Score badges|Best-score tracking|Clinic-visit checklist',
  'Verification': 'Trusted search|Broad web search link|WHO search|Kenya Ministry of Health search|UNICEF search|CDC search|Verification checklist|AI claim assessment|Source-first messaging',
  'Chat and memory': 'Dedicated EMZY Chat page|Big Open EMZY Chat button|Chats saved on device|Multiple chats|Switch between chats|Per-chat answer language|Download a chat as text|Copy any answer|Delete one or all chats|Suggested-question buttons|Live-AI status badge',
  'Photo scan and themes': 'Photo scan page|Skin, medicine, wound and other modes|Photos up to 25 MB accepted|Browser-side image shrinking|Vision AI analysis|Four-part safe answer format|Medicine label reading|No-diagnosis safeguards|Scan history|Search trusted sources from a result|Discuss a result in chat|Dark and light theme toggle|Theme remembered|Follows device theme by default',
  'Reliability': 'Key cleaning (spaces, quotes, Bearer prefix)|Automatic model fallback|Live key health check|Clear error reasons|Offline guide fallback',
  'Vault and large files': 'On-device file vault|Files over 100 MB supported|Up to 1 GB per file|Multi-file upload|File categories|Search files|Download stored files|Delete files|Storage usage meter',
  'Owner tools': 'Live AI connection test|Server-key detection|Case review: approve, need info, reject|Usage statistics|Backup download|Backup restore',
  'Debt relief marketplace': 'Case marketplace|Search cases|Filter by category|Sort by need, progress or size|Progress bars|Demo-case labels|Case submission form|Server-side validation|Case categories|Amount limits|Optional county or town|Bill file-name capture|Truthfulness confirmation|Awaiting-review status|No-ID-numbers warning|Local case storage',
  'Donors': 'Pledge to a case|General relief fund pledge|Four donor tiers|Millionaire Circle tier|Anonymous giving|Pledge validation|Impact-share estimate|Donor board|Pledge totals per case|Simulated-pledge disclaimer|Payment-provider pathway',
  'Health tools': 'BMI calculator|Estimated due date|Clinic-visit checklist|Emergency numbers|Hospital finder link|Five first-aid guides|Call buttons',
  'Privacy and ownership': 'Private owner route|Owner account creation|Salted password hashing|Owner login and logout|Personal dashboard|One-tap data deletion|No patient database|Privacy page|Clear prototype labels',
  'Platform': 'Next.js app|Vercel only|Three-plus API routes|Environment-variable config|Mobile-first layout|Scrollable mobile navigation|Keyboard focus styles|Reduced-motion support|High contrast|Demo tour|Impact page|Features page|README deploy guide'
};
export const metadata = { title: 'Features | EMZY AfyaCheck X' };
export default function Features() {
  const total = Object.values(F).reduce((a, s) => a + s.split('|').length, 0);
  return (
    <div className="wrap pad"><h1>Feature catalog</h1><p className="lede">{total} features built into this version. The list is counted from the code, not estimated.</p>
      <div className="grid">{Object.entries(F).map(([k, s]) => <div className="panel" key={k}><h3>{k} ({s.split('|').length})</h3><ul>{s.split('|').map((x) => <li key={x}>{x}</li>)}</ul></div>)}</div></div>
  );
}
