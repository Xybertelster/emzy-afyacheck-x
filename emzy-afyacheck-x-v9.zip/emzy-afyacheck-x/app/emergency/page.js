const AID = [['Heavy bleeding', 'Press firmly on the wound with a clean cloth. Keep pressing. Get help.'], ['Burns', 'Cool under running water for about 20 minutes. No toothpaste or oil. Cover loosely.'], ['Seizure', 'Clear the area, cushion the head, do not hold the person down or put anything in the mouth. Time it. Call for help.'], ['Stroke signs', 'Face drooping, arm weakness, speech trouble: act fast and get to hospital now.'], ['Choking (adult)', 'If they cannot cough or speak, give firm back blows, then abdominal thrusts, and call for help.']];
export const metadata = { title: 'Emergency | EMZY AfyaCheck X' };
export default function Emergency() {
  return (
    <div className="wrap pad"><h1>Emergency</h1>
      <div className="urgentbar" style={{ fontSize: '1.2rem' }}>Call 999 or 112 now, or go to the nearest hospital.</div>
      <p className="row mt"><a className="btn" href="tel:999">Call 999</a><a className="btn" href="tel:112">Call 112</a><a className="btn alt" href="https://www.google.com/maps/search/hospital+near+me" target="_blank" rel="noopener noreferrer">Find hospitals near me</a></p>
      <h2 className="mt">First-aid awareness</h2><div className="grid" style={{ gridTemplateColumns: '1fr' }}>{AID.map(([t, d]) => <details key={t}><summary>{t}</summary><p>{d}</p></details>)}</div>
      <p className="tag mt">Awareness only. Take a certified first-aid course for hands-on skills.</p></div>
  );
}
