'use client';
import { useState, useEffect } from 'react';
import { get, KES, tier } from '../../lib/store';
const DEMO = [['Demo donor A', 250000], ['Demo donor B', 60000], ['Demo donor C', 12000]];
export default function Board() {
  const [pl, setPl] = useState([]); useEffect(() => setPl(get('afya_pledges', [])), []);
  const t = {}; pl.forEach((p) => { t[p.name] = (t[p.name] || 0) + p.amount; });
  const rows = [...Object.entries(t), ...DEMO].sort((a, b) => b[1] - a[1]).slice(0, 10);
  return (
    <div className="wrap pad"><h1>Donor board</h1><p className="lede">Top pledges on this device plus fictional demo donors. Anonymous gifts are grouped together.</p>
      <div className="grid" style={{ gridTemplateColumns: '1fr' }}>{rows.map(([n, v], i) => <div className="panel row" key={n} style={{ alignItems: 'center' }}><b>{i + 1}. {n}</b><span className="badge" style={{ flex: '0 0 auto' }}>{tier(v)}</span><span style={{ textAlign: 'right' }}>{KES(v)}</span></div>)}</div>
      <p className="mt"><a className="btn" href="/donate">Pledge now</a></p></div>
  );
}
