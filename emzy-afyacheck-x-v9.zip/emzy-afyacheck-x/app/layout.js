import './globals.css';
import ThemeToggle from '../components/ThemeToggle';
import KeyGate from '../components/KeyGate';
export const metadata = { title: 'EMZY AfyaCheck X', description: 'Ask, understand, verify and learn: AI-assisted health literacy for Kenya and beyond.' };
export const viewport = { width: 'device-width', initialScale: 1 };
const THEME = "(function(){try{var t=localStorage.getItem('afya_theme');if(!t&&window.matchMedia('(prefers-color-scheme: dark)').matches)t='dark';if(t)document.documentElement.dataset.theme=t}catch(e){}})()";
export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: THEME }} /></head>
      <body>
        <header className="top"><div className="wrap">
          <a className="brand" href="/">EMZY AfyaCheck <b>X</b></a><ThemeToggle />
          <nav aria-label="Main">
            <a href="/chat" style={{ color: '#F2B705', fontWeight: 700 }}>EMZY Chat</a><a href="/scan">Scan photo</a><a href="/">Home</a><a href="/learn">Learn</a><a href="/myth">Myth check</a><a href="/search">Trusted search</a><a href="/relief">Debt relief</a><a href="/donate">Donate</a><a href="/vault">Vault</a><a href="/tools">Tools</a><a href="/quiz">Quiz</a><a href="/emergency">Emergency</a><a href="/donors">Donor Hub</a><a href="/progress">My learning</a><a href="/campaigns">Campaigns</a><a href="/community">Community</a><a href="/providers">Providers</a><a href="/voice">Voice</a><a href="/evaluation">Answer quality</a><a href="/snake">Snake</a><a href="/feedback">Feedback</a>
          </nav>
        </div></header>
        <div className="notice">Educational information only. Not a diagnosis or prescription. Emergency? Call 999 or 112.</div>
        <KeyGate /><main>{children}</main>
        <footer><div className="wrap">EMZY AfyaCheck X is a hackathon prototype for health literacy. It does not replace a doctor, nurse or clinic.<br /><a href="/leaderboard">Donor board</a> · <a href="/dashboard">My dashboard</a> · <a href="/features">All features</a> · <a href="/demo">Demo</a> · <a href="/impact">Impact</a> · <a href="/privacy">Privacy</a> · <a href="/admin">Admin</a></div></footer>
      </body>
    </html>
  );
}
