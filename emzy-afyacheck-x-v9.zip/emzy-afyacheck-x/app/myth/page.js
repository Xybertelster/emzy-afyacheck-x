'use client';
import { useState } from 'react';
import { LANGS } from '../../lib/lang';
export default function Myth() {
  const [claim, setClaim] = useState(''); const [lang, setLang] = useState('English'); const [res, setRes] = useState(null); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  async function go(e) {
    e.preventDefault(); setErr(''); setRes(null); setBusy(true);
    try { const r = await fetch('/api/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ claim, language: lang }) }); const d = await r.json(); if (!r.ok) throw new Error(d.error); setRes(d); }
    catch (x) { setErr(x.message || 'Check failed.'); } finally { setBusy(false); }
  }
  return (
    <div className="wrap pad" style={{ maxWidth: 680 }}><h1>Myth or fact?</h1><p className="lede">Paste a health claim from WhatsApp, Facebook or a friend. AI gives a first read, then you verify it.</p>
      <form onSubmit={go} className="panel"><label htmlFor="c">Claim</label><textarea id="c" rows={4} value={claim} onChange={(e) => setClaim(e.target.value)} maxLength={600} />
        <label htmlFor="l">Answer language</label><select id="l" value={lang} onChange={(e) => setLang(e.target.value)}>{LANGS.map((l) => <option key={l}>{l}</option>)}</select>
        {err && <p className="err" role="alert">{err}</p>}<p><button disabled={busy}>{busy ? 'Checking…' : 'Check this claim'}</button></p></form>
      {res && <div className="panel mt"><h2 className={'v-' + res.verdict}>{res.verdict}</h2><p>{res.explanation}</p>{res.fallback && <p className="tag">Offline guide in use.</p>}<a className="btn alt" href={`/search`}>Verify in Trusted search</a></div>}
    </div>
  );
}
