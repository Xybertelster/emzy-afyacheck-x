# EMZY AfyaCheck X

Next.js 14 (App Router). Deploys on Vercel only. No database.

## Deploy
1. Push this folder to a GitHub repo (or run `npx vercel` here).
2. In Vercel: Add New Project, import the repo (Framework: Next.js, no changes).
3. Settings > Environment Variables:
   - `GROQ_API_KEY` = your key from console.groq.com
   - `GROQ_MODEL` = `llama-3.3-70b-versatile` (optional)
4. Deploy. Open `/owner` once to create the owner account.

## Local
`npm install`, copy `.env.example` to `.env.local`, then `npm run dev`.

## Important
- Add `GROQ_API_KEY` in Vercel, then **Redeploy**. Env vars only apply to new deployments. Without a key the app uses an offline guide.

## Notes
- Owner account, AI settings and relief requests live in the browser (localStorage). Prototype only.
- Not a diagnostic tool. Educational information only.

## If the AI says offline
Open the home page badge or /owner > Test live AI. It shows Groq's reason (for example 401 Invalid API Key means the key is wrong; no key means the variable is not linked to this project). Redeploy after any change.

## Groq key
Set `GROQ_API_KEY` in Vercel → Settings → Environment Variables, then redeploy. If it is not set, EMZY Chat asks for a key on first open and stores it in that browser only.

## Web learning
When the model says it is unsure (or you tap "Search web"), the server pulls Wikipedia and DuckDuckGo summaries and answers from them, with source links.

## Shared key and feedback (v6)
1. Vercel → Storage → create Upstash Redis and connect it to the project (adds KV_REST_API_URL / KV_REST_API_TOKEN).
2. Add `ADMIN_PASSWORD` in Environment Variables and redeploy.
3. Open `/admin`, enter the password and your Groq key, tap Save key for everyone. Visitors are never asked for a key after that.
Feedback is stored in the same Redis and read at `/admin`.

## v9: Multi-AI engine
- `lib/ai.js` routes every request through Groq, Gemini and OpenRouter with automatic fallback (429/errors move to the next provider; photos prefer Gemini).
- Keys: paste once in the first-run box (saved in the browser, never asked again), or set env vars, or save shared keys at /admin.
- `/chat` is a mobile chat app: drawer, Chat/Work, temporary chat, Library, Images, Projects, Scheduled reminders, Plugins, voice call, photo scanning.
